@echo off
chcp 65001 >nul
cd /d "%~dp0"
call venv\Scripts\activate.bat
echo در حال دریافت اخبار خانه‌کارگر، ایلنا و ایسنا (همراه با عکس)...
python manage.py fetch_rss --all
echo.
echo تمام شد. برو تو پنل ادمین بخش «اخبار ارسالی» رو چک کن.
pause
