from django.contrib.auth.models import User
from rest_framework import serializers

from .models import AdminProfile, Article, LatestNewsItem, MainSlide, NewsSlideItem, QuickLink, Service, get_effective_role


class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = ['id', 'title', 'link', 'accent', 'order']


class MainSlideSerializer(serializers.ModelSerializer):
    class Meta:
        model = MainSlide
        fields = ['id', 'category', 'title', 'date', 'accent', 'image', 'order', 'is_active']


class LatestNewsItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = LatestNewsItem
        fields = ['id', 'category', 'title', 'date', 'accent', 'order']


class QuickLinkSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuickLink
        fields = ['id', 'title', 'url', 'group', 'order']


class NewsSlideItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewsSlideItem
        fields = ['id', 'category', 'title', 'date', 'accent', 'order']


class ArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Article
        fields = [
            'id', 'title', 'category', 'date', 'body', 'image', 'status',
            'created_at', 'updated_at', 'source_name', 'source_url',
        ]


class UserAccountSerializer(serializers.ModelSerializer):
    """
    مدیریت کاربرها (مدیریت/کارکن خانه‌کارگر/عضو) از داخل پنل ادمین.
    role: 'admin' | 'kargar' | 'member' - فقط برای خواندن و نوشتن استفاده می‌شه، پروفایل پشت‌صحنه خودش می‌سازه.
    password: فقط موقع نوشتن (create/update) قابل ارسال، هیچ‌وقت برنمی‌گرده.
    """
    role = serializers.SerializerMethodField()
    password = serializers.CharField(write_only=True, required=False, allow_blank=True)
    new_role = serializers.ChoiceField(
        choices=['admin', 'kargar', 'member'], write_only=True, required=False, source='_new_role'
    )

    class Meta:
        model = User
        fields = ['id', 'username', 'is_active', 'date_joined', 'role', 'password', 'new_role']
        read_only_fields = ['id', 'date_joined']

    def get_role(self, obj):
        return get_effective_role(obj)

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        role = validated_data.pop('_new_role', 'member')
        is_active = validated_data.pop('is_active', True)

        user = User(username=validated_data['username'], is_active=is_active)
        user.is_staff = role in ('admin', 'kargar')
        if password:
            user.set_password(password)
        else:
            raise serializers.ValidationError({'password': 'رمز عبور برای ساخت کاربر جدید الزامی است.'})
        user.save()

        if role in ('admin', 'kargar'):
            AdminProfile.objects.update_or_create(user=user, defaults={'role': role})
        else:
            AdminProfile.objects.filter(user=user).delete()

        return user

    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        role = validated_data.pop('_new_role', None)

        if 'is_active' in validated_data:
            instance.is_active = validated_data['is_active']
        if password:
            instance.set_password(password)
        if role is not None:
            instance.is_staff = role in ('admin', 'kargar')
            if role in ('admin', 'kargar'):
                AdminProfile.objects.update_or_create(user=instance, defaults={'role': role})
            else:
                AdminProfile.objects.filter(user=instance).delete()
        instance.save()
        return instance
