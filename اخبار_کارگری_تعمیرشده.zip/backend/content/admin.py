from adminsortable2.admin import SortableAdminMixin
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User

from .models import AdminProfile, Article, LatestNewsItem, MainSlide, NewsSlideItem, QuickLink, Service


# ============================================================
# افزودن «نقش/سرویس» به فرم ساخت کاربر جدید در /admin/auth/user/
# ============================================================
class AdminProfileInline(admin.StackedInline):
    model = AdminProfile
    can_delete = False
    verbose_name_plural = 'نقش ادمین (سرویس)'
    fk_name = 'user'
    extra = 1
    max_num = 1
    min_num = 0


class CustomUserAdmin(UserAdmin):
    inlines = (AdminProfileInline,)
    list_display = ('username', 'email', 'is_staff', 'is_superuser', 'get_role')

    def get_role(self, obj):
        profile = getattr(obj, 'admin_profile', None)
        return profile.get_role_display() if profile else '—'
    get_role.short_description = 'نقش'


admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)


# ============================================================
# ابزار کمکی: محدود کردن دیدن رکوردها بر اساس دسته/نقش کاربر
# ============================================================
def get_user_category(request):
    """دسته مجاز کاربر جاری؛ اگر سوپریوزر یا ادمین کل باشه None برمی‌گرده (یعنی دسترسی کامل)."""
    if request.user.is_superuser:
        return None
    profile = getattr(request.user, 'admin_profile', None)
    if profile is None or profile.role == 'admin':
        return None
    return profile.category


class CategoryRestrictedAdminMixin:
    """
    این میکسین رو روی هر ادمینی که فیلد category داره می‌ذاریم تا:
    - هر کاربرِ سرویس فقط رکوردهای دسته خودش رو ببینه
    - هنگام ساخت رکورد جدید، دسته به‌صورت خودکار قفل بشه رو دسته خودش
    """
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        category = get_user_category(request)
        if category:
            return qs.filter(category=category)
        return qs

    def save_model(self, request, obj, form, change):
        category = get_user_category(request)
        if category:
            obj.category = category
        super().save_model(request, obj, form, change)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        category = get_user_category(request)
        if category and 'category' in form.base_fields:
            form.base_fields['category'].initial = category
            form.base_fields['category'].disabled = True
        return form


@admin.register(Service)
class ServiceAdmin(SortableAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'accent', 'order')
    list_filter = ('accent',)
    search_fields = ('title',)


@admin.register(MainSlide)
class MainSlideAdmin(CategoryRestrictedAdminMixin, SortableAdminMixin, admin.ModelAdmin):
    # با SortableAdminMixin می‌تونی تو لیست، اسلایدها رو با درگ‌اند‌دراپ جابه‌جا کنی
    list_display = ('title', 'category', 'date', 'is_active', 'order')
    list_filter = ('category', 'is_active')
    search_fields = ('title',)
    list_editable = ('is_active',)


@admin.register(LatestNewsItem)
class LatestNewsItemAdmin(CategoryRestrictedAdminMixin, SortableAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'category', 'date', 'order')
    list_filter = ('category',)
    search_fields = ('title',)


@admin.register(QuickLink)
class QuickLinkAdmin(SortableAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'group', 'url', 'order')
    list_filter = ('group',)
    search_fields = ('title', 'url')


@admin.register(NewsSlideItem)
class NewsSlideItemAdmin(CategoryRestrictedAdminMixin, SortableAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'category', 'date', 'order')
    list_filter = ('category',)
    search_fields = ('title',)


@admin.register(Article)
class ArticleAdmin(CategoryRestrictedAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'category', 'status', 'source_name', 'date', 'created_at')
    list_filter = ('category', 'status', 'source_name')
    search_fields = ('title', 'body')
    date_hierarchy = 'created_at'
