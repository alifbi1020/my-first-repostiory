"""
دستور مدیریتی برای گرفتن خودکار خبر (همراه با عکس) از فید RSS چند خبرگزاری هم‌زمان
و ذخیره‌شون به‌عنوان Article تو دیتابیس، متناسب با دسته‌بندی‌های خود سایت.
خبر تکراری (بر اساس لینک خبر اصلی) دوباره اضافه نمی‌شه.

اجرای همه منابع پیکربندی‌شده با هم:
    python manage.py fetch_rss --all

اجرای یک منبع خاص:
    python manage.py fetch_rss --url "https://www.ilna.ir/rss" --source ایلنا --category کارگری
"""
import mimetypes
from urllib.parse import urlparse

import feedparser
import requests
from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand
from django.utils.html import strip_tags

from content.models import Article

# ============================================================
# پیکربندی منابع: هر خبرگزاری -> آدرس RSS، نام منبع، و دسته‌ای از سایت که خبرهاش توش می‌ره.
# اگه آدرس RSS یکی از این‌ها عوض شد یا کار نکرد، فقط همین‌جا اصلاحش کن.
# ============================================================
SOURCES = [
    {'name': 'خانه‌کارگر', 'url': 'https://www.workerhouse.ir/rss', 'category': 'کارگری'},
    {'name': 'ایلنا', 'url': 'https://www.ilna.ir/rss', 'category': 'کارگری'},
    {'name': 'ایسنا', 'url': 'https://www.isna.ir/rss', 'category': 'کارگری'},
]


class Command(BaseCommand):
    help = 'خبرهای تازه رو (همراه با عکس) از یک یا چند فید RSS می‌گیره و به‌عنوان خبر جدید ذخیره می‌کنه.'

    def add_arguments(self, parser):
        parser.add_argument('--all', action='store_true', help='همه منابع تعریف‌شده در SOURCES رو یکجا اجرا کن')
        parser.add_argument('--url', type=str, help='آدرس فید RSS (وقتی --all نزدی)')
        parser.add_argument('--source', type=str, help='نام منبع خبر (وقتی --all نزدی)')
        parser.add_argument('--category', type=str, help='دسته‌ای که خبرها توش ذخیره بشن (وقتی --all نزدی)')
        parser.add_argument(
            '--status', type=str, default='published', choices=['draft', 'published'],
            help='وضعیت خبرهای وارد شده (پیش‌فرض: منتشرشده)',
        )
        parser.add_argument('--limit', type=int, default=15, help='حداکثر تعداد خبر در هر منبع')

    def handle(self, *args, **options):
        if options['all']:
            jobs = SOURCES
        elif options['url']:
            jobs = [{
                'name': options['source'] or 'نامشخص',
                'url': options['url'],
                'category': options['category'] or 'کارگری',
            }]
        else:
            self.stderr.write(self.style.ERROR('یا --all بزن یا --url رو مشخص کن.'))
            return

        total_created = 0
        for job in jobs:
            created = self.fetch_one(job, options['status'], options['limit'])
            total_created += created

        self.stdout.write(self.style.SUCCESS(f'پایان کار. مجموعاً {total_created} خبر جدید اضافه شد.'))

    def fetch_one(self, job, status, limit):
        url, source_name, category = job['url'], job['name'], job['category']
        self.stdout.write(f'--- {source_name} ({url}) ---')
        feed = feedparser.parse(url)

        if getattr(feed, 'bozo', False) and not feed.entries:
            self.stderr.write(self.style.ERROR(
                f'  [{source_name}] فید خونده نشد. آدرس RSS رو چک کن. خطا: {getattr(feed, "bozo_exception", "نامشخص")}'
            ))
            return 0

        created_count = 0
        skipped_count = 0

        for entry in feed.entries[:limit]:
            link = getattr(entry, 'link', '') or ''
            title = getattr(entry, 'title', '').strip()
            if not title or not link:
                continue

            if Article.objects.filter(source_url=link).exists():
                skipped_count += 1
                continue

            summary_raw = getattr(entry, 'summary', '') or getattr(entry, 'description', '')
            summary = strip_tags(summary_raw).strip()
            published = getattr(entry, 'published', '') or getattr(entry, 'updated', '')

            image_url = self._extract_image_url(entry)

            body = summary or title
            body += f'\n\nمنبع: {source_name}\nلینک خبر اصلی: {link}'

            article = Article(
                title=title[:300],
                category=category,
                date=published[:40] if published else '',
                body=body,
                status=status,
                source_name=source_name,
                source_url=link,
            )

            if image_url:
                self._attach_image(article, image_url)

            article.save()
            created_count += 1

        self.stdout.write(f'  {source_name}: {created_count} خبر جدید، {skipped_count} تکراری رد شد.')
        return created_count

    def _extract_image_url(self, entry):
        if hasattr(entry, 'media_content') and entry.media_content:
            return entry.media_content[0].get('url')
        if hasattr(entry, 'media_thumbnail') and entry.media_thumbnail:
            return entry.media_thumbnail[0].get('url')
        if hasattr(entry, 'links'):
            for l in entry.links:
                if l.get('type', '').startswith('image'):
                    return l.get('href')
        if hasattr(entry, 'enclosures'):
            for enc in entry.enclosures:
                if enc.get('type', '').startswith('image'):
                    return enc.get('href') or enc.get('url')
        return None

    def _attach_image(self, article, image_url):
        try:
            resp = requests.get(image_url, timeout=10)
            resp.raise_for_status()
            content_type = resp.headers.get('Content-Type', '')
            ext = mimetypes.guess_extension(content_type.split(';')[0].strip()) or '.jpg'
            filename = urlparse(image_url).path.split('/')[-1] or f'image{ext}'
            if '.' not in filename:
                filename += ext
            article.image.save(filename, ContentFile(resp.content), save=False)
        except Exception as e:
            self.stderr.write(self.style.WARNING(f'  عکس دانلود نشد ({image_url}): {e}'))
