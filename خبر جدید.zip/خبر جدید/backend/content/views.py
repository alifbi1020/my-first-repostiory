from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from rest_framework import permissions, status, viewsets
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Article, LatestNewsItem, MainSlide, NewsSlideItem, QuickLink, Service, get_effective_role
from .permissions import IsAdminOnly, IsAdminOrKargarForWrite, IsAdminStrict
from .serializers import (
    ArticleSerializer,
    LatestNewsItemSerializer,
    MainSlideSerializer,
    NewsSlideItemSerializer,
    QuickLinkSerializer,
    ServiceSerializer,
    UserAccountSerializer,
)

# دسته‌ای که نقش «kargar» بهش قفله (کارکنان خانه‌کارگر -> فقط گردشگری)
LOCKED_CATEGORY = 'گردشگری'


class LoginView(APIView):
    """
    POST /api/auth/login/   body: {"username": "...", "password": "..."}
    خروجی: توکن + نقش مؤثر کاربر تا فرانت بدونه کدوم پنل رو نشون بده.
    role یکی از این دو مقدار (برای کاربرهای پنل مدیریت): "admin" (مدیر) | "kargar" (کارکن)
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = request.data.get('username', '').strip()
        password = request.data.get('password', '')

        if not username or not password:
            return Response(
                {'detail': 'نام کاربری و رمز عبور الزامی است.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        user = authenticate(request, username=username, password=password)
        if user is None or not user.is_active:
            return Response(
                {'detail': 'نام کاربری یا رمز عبور اشتباه است.'},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        role = get_effective_role(user)
        token, _ = Token.objects.get_or_create(user=user)

        return Response({
            'token': token.key,
            'username': user.username,
            'role': role,  # admin | kargar
            'category': LOCKED_CATEGORY if role == 'kargar' else None,
        })


class LogoutView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        Token.objects.filter(user=request.user).delete()
        return Response({'detail': 'خارج شدید.'})


class CategoryLockedMixin:
    """
    برای ویوست‌هایی که فیلد category دارن (MainSlide/LatestNewsItem/NewsSlideItem/Article):
    - کاربر «kargar» فقط رکوردهای دسته «گردشگری» رو می‌بینه و فقط تو همون دسته می‌تونه بسازه/ویرایش کنه.
    - «admin» همه‌چیز رو کامل می‌بینه و مدیریت می‌کنه.
    - مهمان/عضو فقط با GET (که در permission آزاده) همه رو می‌بینه.
    """
    permission_classes = [IsAdminOrKargarForWrite]

    def get_queryset(self):
        qs = super().get_queryset()
        role = get_effective_role(self.request.user)
        if role == 'kargar' and self.request.method not in ('GET', 'HEAD', 'OPTIONS'):
            qs = qs.filter(category=LOCKED_CATEGORY)
        return qs

    def perform_create(self, serializer):
        role = get_effective_role(self.request.user)
        if role == 'kargar':
            serializer.save(category=LOCKED_CATEGORY)
        else:
            serializer.save()

    def perform_update(self, serializer):
        role = get_effective_role(self.request.user)
        if role == 'kargar':
            serializer.save(category=LOCKED_CATEGORY)
        else:
            serializer.save()


class ServiceViewSet(viewsets.ModelViewSet):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer
    permission_classes = [IsAdminOnly]


class MainSlideViewSet(CategoryLockedMixin, viewsets.ModelViewSet):
    # فقط اسلایدهای فعال رو برای فرانت برمی‌گردونه؛ همه رو تو ادمین می‌بینی
    queryset = MainSlide.objects.filter(is_active=True)
    serializer_class = MainSlideSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        # امکان فیلتر با ?kind=slide یا ?kind=lead برای اینکه فرانت فقط همون نوع رو بگیره
        # (بدون این پارامتر، هر دو نوع با هم برمی‌گردن - مثلاً برای فهرست پنل ادمین)
        kind = self.request.query_params.get('kind')
        if kind:
            qs = qs.filter(kind=kind)
        return qs


class LatestNewsItemViewSet(CategoryLockedMixin, viewsets.ModelViewSet):
    queryset = LatestNewsItem.objects.all()
    serializer_class = LatestNewsItemSerializer


class QuickLinkViewSet(viewsets.ModelViewSet):
    queryset = QuickLink.objects.all()
    serializer_class = QuickLinkSerializer
    permission_classes = [IsAdminOnly]


class NewsSlideItemViewSet(CategoryLockedMixin, viewsets.ModelViewSet):
    queryset = NewsSlideItem.objects.all()
    serializer_class = NewsSlideItemSerializer


class ArticleViewSet(CategoryLockedMixin, viewsets.ModelViewSet):
    serializer_class = ArticleSerializer
    queryset = Article.objects.all()

    def get_queryset(self):
        qs = super().get_queryset()
        # امکان فیلتر با ?category=کارگری برای هر سرویس یا صفحه دسته‌بندی سایت
        category = self.request.query_params.get('category')
        if category:
            qs = qs.filter(category=category)
        status_param = self.request.query_params.get('status')
        if status_param:
            qs = qs.filter(status=status_param)
        else:
            # کاربر مهمان/عضو فقط اخبار منتشرشده رو ببینه؛ مدیریت/کارکن با ?status=draft هم می‌تونن پیش‌نویس‌ها رو ببینن
            role = get_effective_role(self.request.user)
            if role not in ('admin', 'kargar'):
                qs = qs.filter(status='published')
        return qs


class UserAccountViewSet(viewsets.ModelViewSet):
    """
    مدیریت کاربران (افزودن/ویرایش/غیرفعال کردن) - فقط برای «مدیریت» در دسترسه.
    غیرفعال کردن = ست کردن is_active=False (نه حذف کامل، تا سابقه/محتوای قبلیش بمونه).
    """
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserAccountSerializer
    permission_classes = [IsAdminStrict]

    def perform_destroy(self, instance):
        # به‌جای حذف واقعی، غیرفعالش می‌کنیم تا خبرهایی که ثبت کرده از دست نره
        instance.is_active = False
        instance.save()
