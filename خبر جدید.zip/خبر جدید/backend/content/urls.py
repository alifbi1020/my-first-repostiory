from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import (
    ArticleViewSet,
    LatestNewsItemViewSet,
    LoginView,
    LogoutView,
    MainSlideViewSet,
    NewsSlideItemViewSet,
    QuickLinkViewSet,
    ServiceViewSet,
    UserAccountViewSet,
)

router = DefaultRouter()
router.register('services', ServiceViewSet)
router.register('main-slides', MainSlideViewSet)
router.register('latest-news', LatestNewsItemViewSet)
router.register('links', QuickLinkViewSet)
router.register('news-slides', NewsSlideItemViewSet)
router.register('articles', ArticleViewSet, basename='article')
router.register('users', UserAccountViewSet, basename='useraccount')

urlpatterns = [
    path('auth/login/', LoginView.as_view(), name='auth-login'),
    path('auth/logout/', LogoutView.as_view(), name='auth-logout'),
    path('', include(router.urls)),
]
