# Generated manually - افزودن قابلیت آپلود عکس و متن کامل به بخش‌های ادمین

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('content', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='service',
            name='image',
            field=models.ImageField(blank=True, null=True, upload_to='services/', verbose_name='تصویر'),
        ),
        migrations.AddField(
            model_name='mainslide',
            name='body',
            field=models.TextField(blank=True, help_text='اگر پر بشه، می‌تونی متن کامل مرتبط با این اسلاید رو نگه داری.', verbose_name='متن کامل (اختیاری)'),
        ),
        migrations.AddField(
            model_name='latestnewsitem',
            name='image',
            field=models.ImageField(blank=True, null=True, upload_to='latest_news/', verbose_name='تصویر'),
        ),
        migrations.AddField(
            model_name='latestnewsitem',
            name='body',
            field=models.TextField(blank=True, verbose_name='متن کامل (اختیاری)'),
        ),
        migrations.AddField(
            model_name='quicklink',
            name='image',
            field=models.ImageField(blank=True, null=True, upload_to='links/', verbose_name='تصویر'),
        ),
        migrations.AddField(
            model_name='newsslideitem',
            name='image',
            field=models.ImageField(blank=True, null=True, upload_to='news_slides/', verbose_name='تصویر'),
        ),
        migrations.AddField(
            model_name='newsslideitem',
            name='body',
            field=models.TextField(blank=True, verbose_name='متن کامل (اختیاری)'),
        ),
    ]
