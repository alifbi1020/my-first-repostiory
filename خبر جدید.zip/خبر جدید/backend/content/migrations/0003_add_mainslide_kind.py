# Generated manually - افزودن نوع (اسلاید اصلی / لید) به اسلایدها، تا بشه از همون بخش «مدیریت اسلایدشو» هم اسلاید و هم لید اضافه کرد

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('content', '0002_add_image_and_body_fields'),
    ]

    operations = [
        migrations.AddField(
            model_name='mainslide',
            name='kind',
            field=models.CharField(
                choices=[('slide', 'اسلاید اصلی (اسلایدشو)'), ('lead', 'لید (کادر لید زیر خبر)')],
                default='slide',
                max_length=10,
                verbose_name='نوع',
            ),
        ),
    ]
