@echo off
chcp 65001 >nul
cd /d "%~dp0"
call venv\Scripts\activate.bat
echo در حال پر کردن سایت با خبر، اسلاید و لید نمونه در حوزه کارگری...
python manage.py seed_worker_news
echo.
echo تمام شد. صفحه اصلی سایت رو رفرش کن تا محتوا رو ببینی.
pause
