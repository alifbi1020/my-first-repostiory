@echo off
chcp 65001 >nul
cd /d "%~dp0"
call venv\Scripts\activate.bat
echo در حال اجرای سرور...
echo آدرس API:   http://127.0.0.1:8000/api/
echo پنل جنگو:   http://127.0.0.1:8000/admin/
echo برای توقف سرور، Ctrl+C رو بزن.
echo.
python manage.py runserver
