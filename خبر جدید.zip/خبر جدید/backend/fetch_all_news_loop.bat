@echo off
chcp 65001 >nul
cd /d "%~dp0"
call venv\Scripts\activate.bat
echo این پنجره رو باز نگه دار - هر ۱۰ دقیقه یکبار خبر تازه رو از هر سه منبع چک می‌کنه.
echo برای توقف، Ctrl+C رو بزن.
echo.
:loop
python manage.py fetch_rss --all
echo -------------------------------------------
echo ۱۰ دقیقه صبر می‌کنم تا دوباره چک کنم...
timeout /t 600 /nobreak >nul
goto loop
