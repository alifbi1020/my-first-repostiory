@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ====================================================
echo   نصب و راه‌اندازی بک‌اند خانه کارگر
echo ====================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [خطا] پایتون نصب نیست یا به PATH اضافه نشده.
    echo لطفا از python.org پایتون رو نصب کن و موقع نصب تیک "Add python.exe to PATH" رو بزن.
    pause
    exit /b 1
)

if not exist venv (
    echo [1/4] در حال ساخت محیط مجازی...
    python -m venv venv
)

echo [2/4] در حال فعال کردن محیط مجازی...
call venv\Scripts\activate.bat

echo [3/4] در حال نصب کتابخانه‌ها...
pip install -r requirements.txt -q

echo [4/4] در حال ساخت دیتابیس...
python manage.py makemigrations
python manage.py migrate

echo.
echo ====================================================
echo   نصب تمام شد.
echo   حالا باید یک حساب مدیریت (سوپریوزر) بسازی.
echo   یوزرنیم، ایمیل (اختیاری) و رمز عبور رو وارد کن.
echo ====================================================
echo.
python manage.py createsuperuser

echo.
echo همه چیز آماده‌ست. برای اجرای سرور از فایل run.bat استفاده کن.
pause
