from rest_framework import permissions

from .models import get_effective_role

# متدهای «فقط خواندن» که همیشه برای همه (حتی کاربر مهمان و اعضا) آزادن
SAFE_METHODS = ('GET', 'HEAD', 'OPTIONS')


class IsAdminOrKargarForWrite(permissions.BasePermission):
    """
    - خواندن (GET): برای همه آزاده (مهمان، عضو، کارکن، مدیریت) -> اعضا فقط می‌تونن بخونن.
    - نوشتن (POST/PUT/PATCH/DELETE): فقط «مدیریت» و «کارکن خانه‌کارگر» اجازه دارن،
      و کارکن خانه‌کارگر فقط داخل دسته «گردشگری» (چک دقیق‌ترش تو perform_create/queryset ویو انجام می‌شه).
    """

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True
        role = get_effective_role(request.user)
        return role in ('admin', 'kargar')

    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return True
        role = get_effective_role(request.user)
        if role == 'admin':
            return True
        if role == 'kargar':
            return getattr(obj, 'category', None) == 'گردشگری'
        return False


class IsAdminOnly(permissions.BasePermission):
    """برای بخش‌هایی مثل «سرویس‌ها» و «پیوندها» که ساختار کل سایته و فقط مدیریت حق دست‌زدن بهش رو داره."""

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True
        return get_effective_role(request.user) == 'admin'
