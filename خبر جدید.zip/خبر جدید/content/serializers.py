from rest_framework import serializers

from .models import Article, LatestNewsItem, MainSlide, NewsSlideItem, QuickLink, Service


class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = ['id', 'title', 'link', 'accent', 'order']


class MainSlideSerializer(serializers.ModelSerializer):
    class Meta:
        model = MainSlide
        fields = ['id', 'category', 'title', 'date', 'accent', 'image', 'order', 'is_active']


class LatestNewsItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = LatestNewsItem
        fields = ['id', 'category', 'title', 'date', 'accent', 'order']


class QuickLinkSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuickLink
        fields = ['id', 'title', 'url', 'group', 'order']


class NewsSlideItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewsSlideItem
        fields = ['id', 'category', 'title', 'date', 'accent', 'order']


class ArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Article
        fields = ['id', 'title', 'category', 'date', 'body', 'image', 'status', 'created_at', 'updated_at']
