"""
منطق مشترک برای وصل کردن خوراک‌های RSS خبرگزاری‌ها (مثلاً ایلنا) به سایت.
هم از دستور مدیریتی (manage.py fetch_rss) و هم از دکمه‌ی پنل ادمین (فقط مدیرکل) صدا زده می‌شه.

نکته‌ی مهم درباره‌ی شعبه‌ها:
خبرهایی که از RSS وارد می‌شن، فیلد branch شون خالی («سراسری») می‌مونه - یعنی طبق منطق
ArticleViewSet (فیلتر OR روی branch=<شعبه> یا branch='')، این خبرها خودکار روی صفحه‌ی
اخبار *همه‌ی شعبه‌ها* (یزد، تبریز، شیراز، ...) هم نمایش داده می‌شن، بدون این‌که لازم باشه
برای هر شعبه جدا وارد بشن.
"""
import mimetypes
from urllib.parse import urlparse

import feedparser
import requests
from django.core.files.base import ContentFile
from django.utils.html import strip_tags

from .models import Article

# ============================================================
# پیکربندی منابع RSS.
# هر منبع می‌تونه چند آدرس کاندید داشته باشه (urls) - اولین آدرسی که واقعاً فید معتبر
# و خبر داشته باشه استفاده می‌شه. اگه خبرگزاری‌ای فید مخصوص یک دسته (مثلاً فقط «کارگری»)
# نداشت و مجبور شدیم از فید عمومی سایتش استفاده کنیم، با keyword_filter فقط خبرهایی که
# واقعاً به کارگری/کارگر/دستمزد و... مربوطن نگه داشته می‌شن و بقیه (سیاسی، ورزشی، ...) دور ریخته می‌شن.
#
# ⚠️ آدرس اول ایلنا (بخش‌کارگری) حدس زده شده بر اساس ساختار سایتشون؛ اگه بعد از اجرا با خطا
# مواجه شدی یا خبر «کارگری واقعی» ایلنا نیومد، از پنل مدیریت ایلنا/تیم فنی سایتشون آدرس
# دقیق RSS بخش «کارگری» رو بگیر و همینجا جایگزین کن.
SOURCES = [
    {
        'name': 'ایلنا',
        'urls': [
            'https://www.ilna.ir/بخش-کارگری-9/rss',
            'https://www.ilna.ir/rss',
        ],
        'category': 'کارگری',
        'keyword_filter': ['کارگر', 'کارگری', 'کارفرما', 'دستمزد', 'مزد', 'بازنشست', 'تامین اجتماعی', 'اتحادیه', 'سندیکا', 'خانه کارگر'],
    },
    {
        'name': 'توسعه ایرانی',
        'urls': ['https://www.toseeirani.ir/rss'],
        'category': 'کارگری',
        'keyword_filter': None,
    },
    {
        'name': 'روزنامه خانه کارگر',
        'urls': ['https://www.karvakaregar.com/rss'],
        'category': 'کارگری',
        'keyword_filter': None,
    },
]


def _extract_image_url(entry):
    if hasattr(entry, 'media_content') and entry.media_content:
        return entry.media_content[0].get('url')
    if hasattr(entry, 'media_thumbnail') and entry.media_thumbnail:
        return entry.media_thumbnail[0].get('url')
    if hasattr(entry, 'links'):
        for l in entry.links:
            if l.get('type', '').startswith('image'):
                return l.get('href')
    if hasattr(entry, 'enclosures'):
        for enc in entry.enclosures:
            if enc.get('type', '').startswith('image'):
                return enc.get('href') or enc.get('url')
    return None


def _attach_image(article, image_url):
    try:
        resp = requests.get(image_url, timeout=10)
        resp.raise_for_status()
        content_type = resp.headers.get('Content-Type', '')
        ext = mimetypes.guess_extension(content_type.split(';')[0].strip()) or '.jpg'
        filename = urlparse(image_url).path.split('/')[-1] or f'image{ext}'
        if '.' not in filename:
            filename += ext
        article.image.save(filename, ContentFile(resp.content), save=False)
        return None
    except Exception as e:
        return str(e)


def _matches_keywords(entry, keywords):
    if not keywords:
        return True
    haystack = (getattr(entry, 'title', '') + ' ' + getattr(entry, 'summary', '')).lower()
    return any(kw.lower() in haystack for kw in keywords)


def fetch_one(job, status='published', limit=15):
    """
    یک منبع RSS رو می‌گیره، Article های تازه (غیرتکراری، بر اساس لینک خبر) رو با branch=''
    (یعنی سراسری / قابل نمایش روی همه‌ی شعبه‌ها) می‌سازه.
    خروجی: دیکشنری {name, created, skipped, error} برای گزارش به کاربر.
    """
    name = job['name']
    category = job.get('category', 'کارگری')
    keyword_filter = job.get('keyword_filter')
    urls = job.get('urls') or ([job['url']] if job.get('url') else [])

    feed = None
    used_url = None
    last_error = None
    for candidate in urls:
        try:
            f = feedparser.parse(candidate)
        except Exception as e:
            last_error = str(e)
            continue
        if f.entries:
            feed = f
            used_url = candidate
            break
        last_error = str(getattr(f, 'bozo_exception', '')) or 'فید خالی بود یا خونده نشد.'

    if feed is None:
        return {'name': name, 'created': 0, 'skipped': 0, 'error': f'هیچ‌کدام از آدرس‌های RSS جواب ندادن. آخرین خطا: {last_error}'}

    created_count = 0
    skipped_count = 0

    for entry in feed.entries[:limit]:
        link = getattr(entry, 'link', '') or ''
        title = getattr(entry, 'title', '').strip()
        if not title or not link:
            continue
        if not _matches_keywords(entry, keyword_filter):
            continue
        if Article.objects.filter(source_url=link).exists():
            skipped_count += 1
            continue

        summary_raw = getattr(entry, 'summary', '') or getattr(entry, 'description', '')
        summary = strip_tags(summary_raw).strip()
        published = getattr(entry, 'published', '') or getattr(entry, 'updated', '')

        image_url = _extract_image_url(entry)

        body = summary or title
        body += f'\n\nمنبع: {name}\nلینک خبر اصلی: {link}'

        article = Article(
            title=title[:300],
            category=category,
            date=published[:40] if published else '',
            body=body,
            status=status,
            source_name=name,
            source_url=link,
            branch='',  # خالی = سراسری؛ روی صفحه‌ی خبری همه‌ی شعبه‌ها نشون داده می‌شه
        )

        if image_url:
            _attach_image(article, image_url)

        article.save()
        created_count += 1

    return {'name': name, 'created': created_count, 'skipped': skipped_count, 'error': None, 'used_url': used_url}


def fetch_all(jobs=None, status='published', limit=15):
    jobs = jobs if jobs is not None else SOURCES
    return [fetch_one(job, status, limit) for job in jobs]
