"""
دستور مدیریتی برای گرفتن خودکار خبر (همراه با عکس) از فید RSS چند خبرگزاری هم‌زمان
و ذخیره‌شون به‌عنوان Article تو دیتابیس (به‌صورت سراسری، یعنی روی همه‌ی شعبه‌ها نمایش داده می‌شن).
خبر تکراری (بر اساس لینک خبر اصلی) دوباره اضافه نمی‌شه.

اجرای همه منابع پیکربندی‌شده (تو content/rss_import.py) با هم:
    python manage.py fetch_rss --all

اجرای یک منبع خاص (برای تست یه آدرس RSS جدید):
    python manage.py fetch_rss --url "https://www.ilna.ir/بخش-کارگری-9/rss" --source ایلنا --category کارگری

برای اجرای خودکار و دوره‌ای (مثلاً هر ۳۰ دقیقه)، این خط رو به کرون‌تب سرور اضافه کن:
    */30 * * * * cd /path/to/backend && /path/to/venv/bin/python manage.py fetch_rss --all >> /var/log/fetch_rss.log 2>&1
"""
from django.core.management.base import BaseCommand

from content.rss_import import SOURCES, fetch_all, fetch_one


class Command(BaseCommand):
    help = 'خبرهای تازه رو (همراه با عکس) از یک یا چند فید RSS می‌گیره و به‌عنوان خبر سراسری جدید ذخیره می‌کنه.'

    def add_arguments(self, parser):
        parser.add_argument('--all', action='store_true', help='همه منابع تعریف‌شده در content/rss_import.py رو یکجا اجرا کن')
        parser.add_argument('--url', type=str, help='آدرس فید RSS (وقتی --all نزدی)')
        parser.add_argument('--source', type=str, help='نام منبع خبر (وقتی --all نزدی)')
        parser.add_argument('--category', type=str, help='دسته‌ای که خبرها توش ذخیره بشن (وقتی --all نزدی)')
        parser.add_argument(
            '--status', type=str, default='published', choices=['draft', 'published'],
            help='وضعیت خبرهای وارد شده (پیش‌فرض: منتشرشده)',
        )
        parser.add_argument('--limit', type=int, default=15, help='حداکثر تعداد خبر در هر منبع')

    def handle(self, *args, **options):
        if options['all']:
            results = fetch_all(status=options['status'], limit=options['limit'])
        elif options['url']:
            job = {
                'name': options['source'] or 'نامشخص',
                'urls': [options['url']],
                'category': options['category'] or 'کارگری',
                'keyword_filter': None,
            }
            results = [fetch_one(job, options['status'], options['limit'])]
        else:
            self.stderr.write(self.style.ERROR('یا --all بزن یا --url رو مشخص کن.'))
            return

        total_created = 0
        for r in results:
            if r['error']:
                self.stderr.write(self.style.ERROR(f"  [{r['name']}] خطا: {r['error']}"))
                continue
            self.stdout.write(f"  {r['name']}: {r['created']} خبر جدید، {r['skipped']} تکراری رد شد. (از {r.get('used_url', '-')})")
            total_created += r['created']

        self.stdout.write(self.style.SUCCESS(f'پایان کار. مجموعاً {total_created} خبر جدید اضافه شد.'))
