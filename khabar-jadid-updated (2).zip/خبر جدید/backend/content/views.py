from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.db.models import Q
from rest_framework import permissions, status, viewsets
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import (
    Article,
    LatestNewsItem,
    MainSlide,
    NewsSlideItem,
    QuickLink,
    Service,
    get_effective_branch,
    get_effective_role,
)
from .permissions import (
    IsAdminOnly,
    IsAdminOrBranchForWrite,
    IsAdminStrict,
)
from .rss_import import fetch_all
from .serializers import (
    ArticleSerializer,
    LatestNewsItemSerializer,
    MainSlideSerializer,
    NewsSlideItemSerializer,
    QuickLinkSerializer,
    ServiceSerializer,
    UserAccountSerializer,
)


class LoginView(APIView):
    """
    POST /api/auth/login/   body: {"username": "...", "password": "..."}
    خروجی: توکن + نقش مؤثر کاربر + شعبه‌اش، تا فرانت بدونه کدوم پنل/محتوا رو نشون بده.
    role یکی از این سه مقدار (برای کاربرهای پنل مدیریت): "admin" (مدیرکل) | "branch_manager" (مدیر شعبه) | "reporter" (خبرنگار)
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = request.data.get('username', '').strip()
        password = request.data.get('password', '')

        if not username or not password:
            return Response(
                {'detail': 'نام کاربری و رمز عبور الزامی است.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        user = authenticate(request, username=username, password=password)
        if user is None or not user.is_active:
            return Response(
                {'detail': 'نام کاربری یا رمز عبور اشتباه است.'},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        role = get_effective_role(user)
        branch = get_effective_branch(user)
        token, _ = Token.objects.get_or_create(user=user)

        return Response({
            'token': token.key,
            'username': user.username,
            'role': role,  # admin | branch_manager | reporter | member
            'branch': branch,  # فقط برای branch_manager/reporter مقدار داره
        })


class LogoutView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        Token.objects.filter(user=request.user).delete()
        return Response({'detail': 'خارج شدید.'})


class BranchLockedMixin:
    """
    برای ویوست‌هایی که فیلد branch دارن (MainSlide/Article):
    - «مدیر شعبه»/«خبرنگار» فقط رکوردهای شعبه‌ی خودشون رو (وقتی دارن می‌نویسن) می‌بینن و فقط تو
      همون شعبه می‌تونن بسازن/ویرایش کنن.
    - «مدیرکل» همه‌چیز رو کامل می‌بینه و مدیریت می‌کنه (همه‌ی شعبه‌ها).
    - مهمان/عضو فقط با GET (که در permission آزاده) همه رو می‌بینه.
    """
    permission_classes = [IsAdminOrBranchForWrite]

    def get_queryset(self):
        qs = super().get_queryset()
        role = get_effective_role(self.request.user)
        if role in ('branch_manager', 'reporter') and self.request.method not in ('GET', 'HEAD', 'OPTIONS'):
            qs = qs.filter(branch=get_effective_branch(self.request.user))
        return qs

    def perform_create(self, serializer):
        role = get_effective_role(self.request.user)
        if role in ('branch_manager', 'reporter'):
            serializer.save(branch=get_effective_branch(self.request.user) or '')
        else:
            serializer.save()

    def perform_update(self, serializer):
        role = get_effective_role(self.request.user)
        if role in ('branch_manager', 'reporter'):
            serializer.save(branch=get_effective_branch(self.request.user) or '')
        else:
            serializer.save()


class ServiceViewSet(viewsets.ModelViewSet):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer
    permission_classes = [IsAdminOnly]


class MainSlideViewSet(BranchLockedMixin, viewsets.ModelViewSet):
    # فقط اسلایدهای فعال رو برای فرانت برمی‌گردونه؛ همه رو تو ادمین می‌بینی
    queryset = MainSlide.objects.filter(is_active=True)
    serializer_class = MainSlideSerializer
    # اسلایدها برای «مدیرکل»، «مدیر شعبه» و «خبرنگار» هر سه قابل نوشتنه (هر سه در شعبه‌ی خودشون)
    permission_classes = [IsAdminOrBranchForWrite]

    def get_queryset(self):
        qs = super().get_queryset()
        # امکان فیلتر با ?kind=slide یا ?kind=lead برای اینکه فرانت فقط همون نوع رو بگیره
        # (بدون این پارامتر، هر دو نوع با هم برمی‌گردن - مثلاً برای فهرست پنل ادمین)
        kind = self.request.query_params.get('kind')
        if kind:
            qs = qs.filter(kind=kind)
        # امکان فیلتر با ?branch=یزد برای این‌که صفحه اصلی سایت فقط اسلایدهای همون شعبه رو نشون بده.
        # نکته: اسلایدهای «سراسری» (branch='') همیشه همراه با اسلایدهای شعبه‌ی درخواستی هم نشون داده
        # می‌شن - چون قرار نیست محتوای عمومی/مدیرکل از صفحه‌ی هیچ شعبه‌ای حذف بشه.
        branch = self.request.query_params.get('branch')
        if branch:
            qs = qs.filter(Q(branch=branch) | Q(branch=''))
        return qs


class LatestNewsItemViewSet(viewsets.ModelViewSet):
    # بخش سراسری سایته (نه مخصوص شعبه) - فقط مدیرکل مدیریتش می‌کنه
    queryset = LatestNewsItem.objects.all()
    serializer_class = LatestNewsItemSerializer
    permission_classes = [IsAdminOnly]


class QuickLinkViewSet(viewsets.ModelViewSet):
    queryset = QuickLink.objects.all()
    serializer_class = QuickLinkSerializer
    permission_classes = [IsAdminOnly]


class NewsSlideItemViewSet(viewsets.ModelViewSet):
    # بخش سراسری سایته (نه مخصوص شعبه) - فقط مدیرکل مدیریتش می‌کنه
    queryset = NewsSlideItem.objects.all()
    serializer_class = NewsSlideItemSerializer
    permission_classes = [IsAdminOnly]


class ArticleViewSet(BranchLockedMixin, viewsets.ModelViewSet):
    serializer_class = ArticleSerializer
    queryset = Article.objects.all()
    # اخبار برای «مدیرکل»، «مدیر شعبه» و «خبرنگار» هر سه قابل نوشتنه
    permission_classes = [IsAdminOrBranchForWrite]

    def get_queryset(self):
        qs = super().get_queryset()
        # امکان فیلتر با ?category=کارگری برای هر سرویس یا صفحه دسته‌بندی سایت
        category = self.request.query_params.get('category')
        if category:
            qs = qs.filter(category=category)
        # امکان فیلتر با ?branch=یزد برای این‌که صفحه اصلی سایت فقط اخبار همون شعبه رو نشون بده.
        # نکته: اخبار «سراسری» (branch='' - مثلاً خبرهای وارد‌شده از RSS ایلنا یا خبرهای خود
        # مدیرکل که برای شعبه‌ی خاصی نیستن) همیشه همراه با اخبار شعبه‌ی درخواستی هم نشون داده می‌شن؛
        # یعنی یه خبر RSS با یک بار وارد شدن، خودکار روی صفحه‌ی خبریِ *همه‌ی* شعبه‌ها ظاهر می‌شه.
        branch = self.request.query_params.get('branch')
        if branch:
            qs = qs.filter(Q(branch=branch) | Q(branch=''))
        status_param = self.request.query_params.get('status')
        if status_param:
            qs = qs.filter(status=status_param)
        else:
            # کاربر مهمان/عضو فقط اخبار منتشرشده رو ببینه؛ مدیرکل/مدیر شعبه/خبرنگار با ?status=draft هم می‌تونن پیش‌نویس‌ها رو ببینن
            role = get_effective_role(self.request.user)
            if role not in ('admin', 'branch_manager', 'reporter'):
                qs = qs.filter(status='published')
        return qs


class ImportRssView(APIView):
    """
    POST /api/import-rss/  (فقط مدیرکل)
    خبرهای تازه‌ی همه‌ی منابع RSS پیکربندی‌شده (content/rss_import.py - از جمله ایلنا/کارگری)
    رو می‌گیره و به‌عنوان Article سراسری (branch='') ذخیره می‌کنه - یعنی خودکار روی صفحه‌ی
    خبریِ همه‌ی شعبه‌ها هم نمایش داده می‌شه.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        if get_effective_role(request.user) != 'admin':
            return Response({'detail': 'فقط مدیرکل به این بخش دسترسی دارد.'}, status=status.HTTP_403_FORBIDDEN)
        results = fetch_all()
        total_created = sum(r['created'] for r in results)
        return Response({'created': total_created, 'sources': results})


class UserAccountViewSet(viewsets.ModelViewSet):
    """
    مدیریت کاربران (افزودن/ویرایش/غیرفعال کردن):
    - «مدیرکل»: به همه‌ی کاربران (هر نقشی) دسترسی کامل داره.
    - «مدیر شعبه»: فقط به «خبرنگارهایی» که خودش ساخته دسترسی داره (فقط همون‌ها رو می‌بینه/ویرایش می‌کنه)
      و فقط اجازه داره خبرنگار جدید بسازه (نه مدیر شعبه یا مدیرکل دیگه).
    - «خبرنگار»/عضو/مهمان: اصلاً دسترسی نداره.
    غیرفعال کردن = ست کردن is_active=False (نه حذف کامل، تا سابقه/محتوای قبلیش بمونه).
    """
    serializer_class = UserAccountSerializer
    permission_classes = [IsAdminStrict]

    def get_queryset(self):
        qs = User.objects.all().order_by('-date_joined')
        role = get_effective_role(self.request.user)
        if role == 'branch_manager':
            # مدیر شعبه فقط خبرنگارهایی که خودش ساخته رو می‌بینه
            qs = qs.filter(admin_profile__created_by=self.request.user, admin_profile__role='reporter')
        return qs

    def perform_destroy(self, instance):
        # به‌جای حذف واقعی، غیرفعالش می‌کنیم تا خبرهایی که ثبت کرده از دست نره
        instance.is_active = False
        instance.save()
