# افزودن نقش‌های «مدیر شعبه» و «خبرنگار» به‌جای «کارکن»، به‌همراه فیلد شعبه/استان
# روی پروفایل ادمین و روی اسلایدها/اخبار، تا هر شعبه فقط محتوای خودش را مدیریت کند.

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


def migrate_kargar_to_branch_manager(apps, schema_editor):
    """کاربرهایی که قبلاً نقش 'kargar' داشتند را به 'branch_manager' تبدیل می‌کند
    (شعبه‌شان خالی می‌ماند تا مدیرکل بعداً از پنل ادمین برایشان مشخص کند)."""
    AdminProfile = apps.get_model('content', 'AdminProfile')
    AdminProfile.objects.filter(role='kargar').update(role='branch_manager', branch='')


def noop_reverse(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('content', '0003_add_mainslide_kind'),
    ]

    operations = [
        migrations.AlterField(
            model_name='adminprofile',
            name='role',
            field=models.CharField(
                choices=[
                    ('admin', 'مدیرکل (دسترسی کامل)'),
                    ('branch_manager', 'مدیر شعبه'),
                    ('reporter', 'خبرنگار'),
                ],
                default='admin',
                max_length=20,
                verbose_name='نقش',
            ),
        ),
        migrations.AddField(
            model_name='adminprofile',
            name='branch',
            field=models.CharField(
                blank=True, default='', max_length=100, verbose_name='شعبه / استان',
                help_text='مثلاً: یزد. فقط برای «مدیر شعبه» و «خبرنگار» پر می‌شود؛ توسط مدیرکل (یا مدیر شعبه، هنگام ساخت خبرنگار) تعیین می‌شود.',
            ),
        ),
        migrations.AddField(
            model_name='adminprofile',
            name='created_by',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='created_admin_profiles',
                to=settings.AUTH_USER_MODEL,
                verbose_name='ساخته‌شده توسط',
                help_text='مدیر شعبه‌ای که این خبرنگار را ساخته (برای محدود کردن دید هر مدیر شعبه فقط به خبرنگارهای خودش).',
            ),
        ),
        migrations.AddField(
            model_name='mainslide',
            name='branch',
            field=models.CharField(
                blank=True, default='', max_length=100, verbose_name='شعبه',
                help_text='شعبه/استانی که این اسلاید متعلق به آن است (اگر توسط مدیر شعبه ساخته شده باشد، خودکار پر می‌شود). برای اسلایدهای عمومی/مدیرکل خالی بگذارید.',
            ),
        ),
        migrations.AddField(
            model_name='article',
            name='branch',
            field=models.CharField(
                blank=True, default='', max_length=100, verbose_name='شعبه',
                help_text='شعبه/استانی که این خبر متعلق به آن است (اگر توسط مدیر شعبه یا خبرنگار ساخته شده باشد، خودکار پر می‌شود).',
            ),
        ),
        migrations.RunPython(migrate_kargar_to_branch_manager, noop_reverse),
    ]
