from django.contrib.auth.models import User
from rest_framework import serializers

from .models import (
    AdminProfile,
    Article,
    LatestNewsItem,
    MainSlide,
    NewsSlideItem,
    QuickLink,
    ROLES_CREATABLE_BY,
    Service,
    get_effective_branch,
    get_effective_role,
)


class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = ['id', 'title', 'link', 'accent', 'image', 'order']


class MainSlideSerializer(serializers.ModelSerializer):
    branch = serializers.CharField(required=False, allow_blank=True)

    class Meta:
        model = MainSlide
        fields = ['id', 'kind', 'category', 'title', 'date', 'accent', 'image', 'body', 'order', 'is_active', 'branch']
        # توجه: برای «مدیر شعبه»/«خبرنگار» مقدار این فیلد همیشه تو ویو (BranchLockedMixin) اورراید
        # می‌شه با شعبه‌ی خودشون؛ فقط «مدیرکل» می‌تونه آزادانه هر شعبه‌ای (یا خالی = سراسری) بفرسته.


class LatestNewsItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = LatestNewsItem
        fields = ['id', 'category', 'title', 'date', 'accent', 'image', 'body', 'order']


class QuickLinkSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuickLink
        fields = ['id', 'title', 'url', 'group', 'image', 'order']


class NewsSlideItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewsSlideItem
        fields = ['id', 'category', 'title', 'date', 'accent', 'image', 'body', 'order']


class ArticleSerializer(serializers.ModelSerializer):
    branch = serializers.CharField(required=False, allow_blank=True)

    class Meta:
        model = Article
        fields = [
            'id', 'title', 'category', 'date', 'body', 'image', 'status',
            'created_at', 'updated_at', 'source_name', 'source_url', 'branch',
        ]
        # توجه: برای «مدیر شعبه»/«خبرنگار» مقدار این فیلد همیشه تو ویو (BranchLockedMixin) اورراید
        # می‌شه با شعبه‌ی خودشون؛ فقط «مدیرکل» می‌تونه آزادانه هر شعبه‌ای (یا خالی = سراسری) بفرسته.


class UserAccountSerializer(serializers.ModelSerializer):
    """
    مدیریت کاربرها (مدیرکل / مدیر شعبه / خبرنگار) از داخل پنل ادمین.
    role: 'admin' | 'branch_manager' | 'reporter' - فقط برای خواندن و نوشتن استفاده می‌شه، پروفایل پشت‌صحنه خودش می‌سازه.
    branch: شعبه/استان - فقط برای «مدیر شعبه» و «خبرنگار» معنی داره.
    password: فقط موقع نوشتن (create/update) قابل ارسال، هیچ‌وقت برنمی‌گرده.

    محدودیت‌های نقشی (اجرای واقعیِ امنیتی‌شون تو UserAccountViewSet انجام می‌شه، این‌جا فقط
    مقداردهی پیش‌فرض/خودکارِ role و branch بر اساس کاربرِ درخواست‌دهنده انجام می‌شه):
    - «مدیرکل» می‌تونه هر سه نقش رو با هر شعبه‌ای بسازه.
    - «مدیر شعبه» فقط می‌تونه «خبرنگار» بسازه و شعبه‌ی خبرنگار خودکار همون شعبه‌ی خودش می‌شه.
    """
    role = serializers.SerializerMethodField()
    branch = serializers.SerializerMethodField()
    password = serializers.CharField(write_only=True, required=False, allow_blank=True)
    new_role = serializers.ChoiceField(
        choices=['admin', 'branch_manager', 'reporter'], write_only=True, required=False, source='_new_role'
    )
    new_branch = serializers.CharField(
        write_only=True, required=False, allow_blank=True, source='_new_branch'
    )

    class Meta:
        model = User
        fields = ['id', 'username', 'is_active', 'date_joined', 'role', 'branch', 'password', 'new_role', 'new_branch']
        read_only_fields = ['id', 'date_joined']

    def get_role(self, obj):
        return get_effective_role(obj)

    def get_branch(self, obj):
        return get_effective_branch(obj)

    def _requesting_role(self):
        request = self.context.get('request')
        return get_effective_role(request.user) if request else None

    def _requesting_branch(self):
        request = self.context.get('request')
        return get_effective_branch(request.user) if request else None

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        requested_role = validated_data.pop('_new_role', 'reporter')
        requested_branch = validated_data.pop('_new_branch', '')
        requesting_role = self._requesting_role()

        # هرکسی فقط اجازه داره نقش‌هایی که تو ROLES_CREATABLE_BY مجازه بسازه؛
        # (چک نهایی/سخت‌گیرانه‌تر تو UserAccountViewSet.perform_create انجام می‌شه)
        allowed_roles = ROLES_CREATABLE_BY.get(requesting_role, [])
        role = requested_role if requested_role in allowed_roles else (allowed_roles[0] if allowed_roles else 'reporter')

        if requesting_role == 'branch_manager':
            # مدیر شعبه فقط می‌تونه خبرنگار بسازه، و شعبه‌اش همیشه همون شعبه خودشه
            role = 'reporter'
            branch = self._requesting_branch() or ''
        else:
            branch = requested_branch

        is_active = validated_data.pop('is_active', True)

        user = User(username=validated_data['username'], is_active=is_active)
        user.is_staff = True
        if password:
            user.set_password(password)
        else:
            raise serializers.ValidationError({'password': 'رمز عبور برای ساخت کاربر جدید الزامی است.'})
        user.save()

        request = self.context.get('request')
        AdminProfile.objects.update_or_create(
            user=user,
            defaults={
                'role': role,
                'branch': branch,
                'created_by': request.user if request else None,
            },
        )

        return user

    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        role = validated_data.pop('_new_role', None)
        branch = validated_data.pop('_new_branch', None)
        requesting_role = self._requesting_role()

        if 'is_active' in validated_data:
            instance.is_active = validated_data['is_active']
        if password:
            instance.set_password(password)

        if role is not None or branch is not None:
            profile = getattr(instance, 'admin_profile', None)
            defaults = {}
            if requesting_role == 'branch_manager':
                # مدیر شعبه فقط اجازه داره خبرنگارهای خودش رو ویرایش کنه و نقش‌شون همیشه خبرنگار می‌مونه
                defaults['role'] = 'reporter'
                defaults['branch'] = self._requesting_branch() or ''
            else:
                if role is not None:
                    defaults['role'] = role
                elif profile:
                    defaults['role'] = profile.role
                if branch is not None:
                    defaults['branch'] = branch
                elif profile:
                    defaults['branch'] = profile.branch
            instance.is_staff = True
            AdminProfile.objects.update_or_create(user=instance, defaults=defaults)

        instance.save()
        return instance
