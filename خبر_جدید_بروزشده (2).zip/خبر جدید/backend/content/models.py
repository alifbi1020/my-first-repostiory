from django.db import models

# دسته‌های خبری - همونایی که تو admin.js داشتیم + "عکس" برای سرویس عکس
CATEGORY_CHOICES = [
    ('کارگری', 'کارگری'),
    ('بازنشستگان', 'بازنشستگان'),
    ('آموزشی', 'آموزشی'),
    ('گردشگری', 'گردشگری'),
    ('فرهنگی', 'فرهنگی'),
    ('تعاونی مصرف', 'تعاونی مصرف'),
    ('عکس', 'عکس'),
]

ACCENT_CHOICES = [
    ('teal', 'فیروزه‌ای'),
    ('gold', 'طلایی'),
]

STATUS_CHOICES = [
    ('draft', 'پیش‌نویس'),
    ('published', 'منتشرشده'),
]

# چهار سطح دسترسیِ سایت:
# - admin          => مدیرکل: دسترسی کامل به همه‌ی بخش‌ها و همه‌ی شعبه‌ها
# - branch_manager => مدیر شعبه (مثلاً «مدیر خانه‌کارگر یزد»): فقط اسلایدها و اخبار *شعبه‌ی خودش*
#                      رو می‌بینه/می‌سازه، و فقط اجازه داره برای شعبه‌ی خودش یک نقش دیگه یعنی
#                      «خبرنگار» بسازه. استانش/شعبه‌اش رو مدیرکل موقع ساختنش تعیین می‌کنه.
# - reporter       => خبرنگار: فقط اجازه داره خبر (اخبار شعبه‌ای که برایش تعریف شده) اضافه/ویرایش کنه.
# - عضو (member) توی این مدل نیست چون کاربر «staff» نیست؛ هر یوزر جنگویی که is_staff نداشته
#   باشه و پروفایل ادمین هم نداشته باشه، خودکار «عضو» محسوب می‌شه (فقط اجازه خواندن/لاگین داره).
ROLE_CHOICES = [
    ('admin', 'مدیرکل (دسترسی کامل)'),
    ('branch_manager', 'مدیر شعبه'),
    ('reporter', 'خبرنگار'),
]

# نقش‌هایی که هر نقش اجازه داره از داخل پنل خودش بسازه (برای بخش «افزودن ادمین»)
ROLES_CREATABLE_BY = {
    'admin': ['admin', 'branch_manager', 'reporter'],
    'branch_manager': ['reporter'],
}


class Service(models.Model):
    """معادل بخش «مدیریت سرویس‌ها» در پنل ادمین."""
    title = models.CharField('عنوان', max_length=100)
    link = models.CharField('لینک', max_length=255)
    accent = models.CharField('رنگ', max_length=10, choices=ACCENT_CHOICES, default='teal')
    image = models.ImageField('تصویر', upload_to='services/', blank=True, null=True)
    order = models.PositiveIntegerField('ترتیب', default=0)

    class Meta:
        verbose_name = 'سرویس'
        verbose_name_plural = 'سرویس‌ها'
        ordering = ['order']

    def __str__(self):
        return self.title


SLIDE_KIND_CHOICES = [
    ('slide', 'اسلاید اصلی (اسلایدشو)'),
    ('lead', 'لید (کادر لید زیر خبر)'),
]


class MainSlide(models.Model):
    """معادل بخش «مدیریت اسلایدشو» - هم اسلایدهای بزرگ صفحه اول، هم آیتم‌های «لید»
    (کادر مستطیلی با عکس و متن که زیر خبرها/در صفحه دسته نمایش داده می‌شه)، با فیلد kind از هم جدا می‌شن."""
    kind = models.CharField('نوع', max_length=10, choices=SLIDE_KIND_CHOICES, default='slide')
    category = models.CharField('دسته', max_length=30, choices=CATEGORY_CHOICES)
    title = models.CharField('عنوان خبر', max_length=300)
    date = models.CharField('تاریخ', max_length=40, help_text='مثلاً: ۲۹ تیر ۱۴۰۴')
    accent = models.CharField('رنگ', max_length=10, choices=ACCENT_CHOICES, default='teal')
    image = models.ImageField('تصویر', upload_to='main_slides/', blank=True, null=True)
    body = models.TextField('متن کامل (اختیاری)', blank=True, help_text='اگر پر بشه، می‌تونی متن کامل مرتبط با این اسلاید رو نگه داری.')
    order = models.PositiveIntegerField('ترتیب', default=0)
    is_active = models.BooleanField('فعال', default=True)
    branch = models.CharField(
        'شعبه', max_length=100, blank=True, default='',
        help_text='شعبه/استانی که این اسلاید متعلق به آن است (اگر توسط مدیر شعبه ساخته شده باشد، خودکار پر می‌شود). برای اسلایدهای عمومی/مدیرکل خالی بگذارید.',
    )

    class Meta:
        verbose_name = 'اسلاید اصلی'
        verbose_name_plural = 'اسلایدشوی اصلی'
        ordering = ['order']

    def __str__(self):
        return self.title


class LatestNewsItem(models.Model):
    """معادل بخش «مدیریت آخرین اخبار»."""
    category = models.CharField('دسته', max_length=30, choices=CATEGORY_CHOICES)
    title = models.CharField('عنوان خبر', max_length=300)
    date = models.CharField('تاریخ', max_length=40)
    accent = models.CharField('رنگ', max_length=10, choices=ACCENT_CHOICES, default='teal')
    image = models.ImageField('تصویر', upload_to='latest_news/', blank=True, null=True)
    body = models.TextField('متن کامل (اختیاری)', blank=True)
    order = models.PositiveIntegerField('ترتیب', default=0)

    class Meta:
        verbose_name = 'خبر (آخرین اخبار)'
        verbose_name_plural = 'آخرین اخبار'
        ordering = ['order']

    def __str__(self):
        return self.title


class QuickLink(models.Model):
    """معادل بخش «مدیریت پیوندها» (فوتر / منوها)."""
    title = models.CharField('عنوان', max_length=150)
    url = models.CharField('آدرس', max_length=255)
    group = models.CharField('گروه', max_length=100, help_text='مثلاً: دسترسی سریع، سامانه‌های مرتبط')
    image = models.ImageField('تصویر', upload_to='links/', blank=True, null=True)
    order = models.PositiveIntegerField('ترتیب', default=0)

    class Meta:
        verbose_name = 'پیوند'
        verbose_name_plural = 'پیوندها'
        ordering = ['group', 'order']

    def __str__(self):
        return self.title


class NewsSlideItem(models.Model):
    """معادل بخش «مدیریت اسلایدشو اخبار» (اسلایدرهای کوچک به تفکیک دسته)."""
    category = models.CharField('دسته', max_length=30, choices=CATEGORY_CHOICES)
    title = models.CharField('عنوان خبر', max_length=300)
    date = models.CharField('تاریخ', max_length=40)
    accent = models.CharField('رنگ', max_length=10, choices=ACCENT_CHOICES, default='teal')
    image = models.ImageField('تصویر', upload_to='news_slides/', blank=True, null=True)
    body = models.TextField('متن کامل (اختیاری)', blank=True)
    order = models.PositiveIntegerField('ترتیب', default=0)

    class Meta:
        verbose_name = 'اسلاید خبری'
        verbose_name_plural = 'اسلایدشوی اخبار'
        ordering = ['order']

    def __str__(self):
        return self.title


class Article(models.Model):
    """معادل بخش «ارسال خبر» - هم برای ادمین کل و هم برای هر سرویس (فیلتر بر اساس category)."""
    title = models.CharField('عنوان خبر', max_length=300)
    category = models.CharField('دسته', max_length=30, choices=CATEGORY_CHOICES)
    date = models.CharField('تاریخ انتشار', max_length=40)
    body = models.TextField('متن خبر')
    image = models.ImageField('تصویر خبر', upload_to='articles/', blank=True, null=True)
    status = models.CharField('وضعیت', max_length=10, choices=STATUS_CHOICES, default='draft')
    created_at = models.DateTimeField('تاریخ ثبت', auto_now_add=True)
    updated_at = models.DateTimeField('آخرین ویرایش', auto_now=True)

    # برای خبرهایی که به‌صورت خودکار از RSS خبرگزاری‌ها (مثل ایلنا) گرفته می‌شن
    source_name = models.CharField('منبع خبر', max_length=100, blank=True, help_text='مثلاً: ایلنا')
    source_url = models.URLField('لینک خبر اصلی', max_length=500, blank=True, unique=False)
    branch = models.CharField(
        'شعبه', max_length=100, blank=True, default='',
        help_text='شعبه/استانی که این خبر متعلق به آن است (اگر توسط مدیر شعبه یا خبرنگار ساخته شده باشد، خودکار پر می‌شود).',
    )

    class Meta:
        verbose_name = 'خبر'
        verbose_name_plural = 'اخبار ارسالی'
        ordering = ['-created_at']

    def __str__(self):
        return self.title

class AdminProfile(models.Model):
    """
    پروفایل هر کاربر «کارکن سایت» - مشخص می‌کنه این کاربر «مدیرکل»، «مدیر شعبه» یا «خبرنگار»‌ه.
    این مدل به مدل کاربر پیش‌فرض جنگو (User) وصل می‌شه. اگر کاربری این پروفایل رو نداشته باشه، «عضو» محسوب می‌شه.
    """
    user = models.OneToOneField(
        'auth.User',
        on_delete=models.CASCADE,
        related_name='admin_profile',
        verbose_name='کاربر',
    )
    role = models.CharField('نقش', max_length=20, choices=ROLE_CHOICES, default='admin')
    branch = models.CharField(
        'شعبه / استان', max_length=100, blank=True, default='',
        help_text='مثلاً: یزد. فقط برای «مدیر شعبه» و «خبرنگار» پر می‌شود؛ توسط مدیرکل (یا مدیر شعبه، هنگام ساخت خبرنگار) تعیین می‌شود.',
    )
    created_by = models.ForeignKey(
        'auth.User',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='created_admin_profiles',
        verbose_name='ساخته‌شده توسط',
        help_text='مدیر شعبه‌ای که این خبرنگار را ساخته (برای محدود کردن دید هر مدیر شعبه فقط به خبرنگارهای خودش).',
    )

    class Meta:
        verbose_name = 'پروفایل ادمین'
        verbose_name_plural = 'پروفایل‌های ادمین'

    def __str__(self):
        label = f'{self.user.username} ({self.get_role_display()})'
        return f'{label} - {self.branch}' if self.branch else label


def get_effective_role(user):
    """
    نقش مؤثر یک کاربر لاگین‌کرده رو برمی‌گردونه: 'admin' | 'branch_manager' | 'reporter' | 'member'.
    - سوپریوزر یا کسی که پروفایلش role='admin' باشه => 'admin'
    - کسی که پروفایلش role='branch_manager' باشه => 'branch_manager' (فقط شعبه خودش)
    - کسی که پروفایلش role='reporter' باشه => 'reporter' (فقط ثبت/ویرایش خبر شعبه خودش)
    - هر کاربر دیگه‌ای که لاگین کرده باشه ولی پروفایل ادمین نداشته باشه => 'member'
    """
    if not user or not user.is_authenticated:
        return None
    if user.is_superuser:
        return 'admin'
    profile = getattr(user, 'admin_profile', None)
    if profile is not None:
        return profile.role
    return 'member'


def get_effective_branch(user):
    """شعبه‌ی مؤثر کاربر (برای branch_manager/reporter)؛ برای admin/member چیزی برنمی‌گردونه (None)."""
    if not user or not user.is_authenticated or user.is_superuser:
        return None
    profile = getattr(user, 'admin_profile', None)
    if profile is not None and profile.role in ('branch_manager', 'reporter'):
        return profile.branch
    return None
