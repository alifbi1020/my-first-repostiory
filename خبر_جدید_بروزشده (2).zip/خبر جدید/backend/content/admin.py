from adminsortable2.admin import SortableAdminMixin
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User

from .models import AdminProfile, Article, LatestNewsItem, MainSlide, NewsSlideItem, QuickLink, Service


# ============================================================
# افزودن «نقش/شعبه» به فرم ساخت کاربر جدید در /admin/auth/user/
# ============================================================
class AdminProfileInline(admin.StackedInline):
    model = AdminProfile
    can_delete = False
    fk_name = 'user'
    extra = 1
    max_num = 1
    min_num = 0
    verbose_name_plural = 'نقش ادمین (مدیرکل / مدیر شعبه / خبرنگار)'
    fields = ('role', 'branch', 'created_by')


class CustomUserAdmin(UserAdmin):
    inlines = (AdminProfileInline,)
    list_display = ('username', 'email', 'is_staff', 'is_superuser', 'get_role', 'get_branch')

    def get_role(self, obj):
        profile = getattr(obj, 'admin_profile', None)
        return profile.get_role_display() if profile else '—'
    get_role.short_description = 'نقش'

    def get_branch(self, obj):
        profile = getattr(obj, 'admin_profile', None)
        return profile.branch if profile else '—'
    get_branch.short_description = 'شعبه'


admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)


# ============================================================
# ابزار کمکی: محدود کردن دیدن رکوردها بر اساس شعبه/نقش کاربر
# ============================================================
def get_user_branch(request):
    """شعبه‌ی مجاز کاربر جاری؛ اگر سوپریوزر یا مدیرکل باشه None برمی‌گرده (یعنی دسترسی کامل)."""
    if request.user.is_superuser:
        return None
    profile = getattr(request.user, 'admin_profile', None)
    if profile is None or profile.role == 'admin':
        return None
    return profile.branch


class BranchRestrictedAdminMixin:
    """
    این میکسین رو روی هر ادمینی که فیلد branch داره (MainSlide/Article) می‌ذاریم تا:
    - هر مدیر شعبه/خبرنگار فقط رکوردهای شعبه‌ی خودش رو ببینه
    - هنگام ساخت رکورد جدید، شعبه به‌صورت خودکار قفل بشه رو شعبه‌ی خودش
    """
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        branch = get_user_branch(request)
        if branch:
            return qs.filter(branch=branch)
        return qs

    def save_model(self, request, obj, form, change):
        branch = get_user_branch(request)
        if branch:
            obj.branch = branch
        super().save_model(request, obj, form, change)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        branch = get_user_branch(request)
        if branch and 'branch' in form.base_fields:
            form.base_fields['branch'].initial = branch
            form.base_fields['branch'].disabled = True
        return form


@admin.register(Service)
class ServiceAdmin(SortableAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'accent', 'order')
    list_filter = ('accent',)
    search_fields = ('title',)


@admin.register(MainSlide)
class MainSlideAdmin(BranchRestrictedAdminMixin, SortableAdminMixin, admin.ModelAdmin):
    # با SortableAdminMixin می‌تونی تو لیست، اسلایدها رو با درگ‌اند‌دراپ جابه‌جا کنی
    list_display = ('title', 'kind', 'category', 'branch', 'date', 'is_active', 'order')
    list_filter = ('kind', 'category', 'branch', 'is_active')
    search_fields = ('title',)
    list_editable = ('is_active',)


@admin.register(LatestNewsItem)
class LatestNewsItemAdmin(SortableAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'category', 'date', 'order')
    list_filter = ('category',)
    search_fields = ('title',)


@admin.register(QuickLink)
class QuickLinkAdmin(SortableAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'group', 'url', 'order')
    list_filter = ('group',)
    search_fields = ('title', 'url')


@admin.register(NewsSlideItem)
class NewsSlideItemAdmin(SortableAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'category', 'date', 'order')
    list_filter = ('category',)
    search_fields = ('title',)


@admin.register(Article)
class ArticleAdmin(BranchRestrictedAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'category', 'branch', 'status', 'source_name', 'date', 'created_at')
    list_filter = ('category', 'branch', 'status', 'source_name')
    search_fields = ('title', 'body')
    date_hierarchy = 'created_at'
