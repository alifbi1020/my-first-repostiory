from rest_framework import permissions

from .models import get_effective_branch, get_effective_role

# متدهای «فقط خواندن» که همیشه برای همه (حتی کاربر مهمان و اعضا) آزادن
SAFE_METHODS = ('GET', 'HEAD', 'OPTIONS')


class IsAdminOrBranchForWrite(permissions.BasePermission):
    """
    برای مدل‌هایی که فیلد branch دارن (Article):
    - خواندن (GET): برای همه آزاده (مهمان، عضو، مدیر شعبه، خبرنگار، مدیرکل).
    - نوشتن (POST/PUT/PATCH/DELETE): «مدیرکل»، «مدیر شعبه» و «خبرنگار» اجازه دارن؛
      مدیر شعبه/خبرنگار فقط داخل شعبه خودشون (چک دقیق‌ترش تو perform_create/queryset ویو انجام می‌شه).
    """

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True
        role = get_effective_role(request.user)
        return role in ('admin', 'branch_manager', 'reporter')

    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return True
        role = get_effective_role(request.user)
        if role == 'admin':
            return True
        if role in ('branch_manager', 'reporter'):
            return getattr(obj, 'branch', None) == get_effective_branch(request.user)
        return False


class IsAdminOrBranchManagerForWrite(permissions.BasePermission):
    """
    مثل بالا، ولی برای بخش‌هایی مثل «اسلایدها» که خبرنگار اجازه‌ی دست‌زدن بهش رو نداره،
    فقط «مدیرکل» و «مدیر شعبه» اجازه‌ی نوشتن دارن.
    """

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True
        role = get_effective_role(request.user)
        return role in ('admin', 'branch_manager')

    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return True
        role = get_effective_role(request.user)
        if role == 'admin':
            return True
        if role == 'branch_manager':
            return getattr(obj, 'branch', None) == get_effective_branch(request.user)
        return False


class IsAdminOnly(permissions.BasePermission):
    """برای بخش‌هایی مثل «سرویس‌ها»، «پیوندها»، «آخرین اخبار» و «اسلایدشوی اخبار» که ساختار
    کل سایته و فقط مدیرکل حق دست‌زدن بهش رو داره؛ مدیر شعبه و خبرنگار اصلاً بهش دسترسی ندارن."""

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True
        return get_effective_role(request.user) == 'admin'


class IsAdminStrict(permissions.BasePermission):
    """
    برای اطلاعات حساس مثل «مدیریت کاربران» - برخلاف IsAdminOnly، حتی GET هم عمومی نیست.
    «مدیرکل» و «مدیر شعبه» اجازه‌ی دیدن/کار با این بخش رو دارن (مدیر شعبه فقط خبرنگارهای خودش رو -
    این محدودیت تو ویو چک می‌شه)؛ «خبرنگار» و «عضو»/مهمان اصلاً اجازه ندارن.
    """

    def has_permission(self, request, view):
        return get_effective_role(request.user) in ('admin', 'branch_manager')
