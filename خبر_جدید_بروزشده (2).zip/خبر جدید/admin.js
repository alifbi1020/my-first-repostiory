(function(){
  "use strict";

  /* ============================================================
     AUTH GUARD
     ============================================================ */
  var auth = sessionStorage.getItem('hk_admin_auth') || localStorage.getItem('hk_admin_auth');
  if(!auth){
    window.location.href = 'login.html';
    return;
  }
  var authData = null;
  try{ authData = JSON.parse(auth); }catch(e){}

  // آدرس بک‌اند - برای بخش «مدیریت کاربران» که واقعاً باید با دیتابیس کار کنه
  var API_BASE = 'http://127.0.0.1:8000/api';
  var BACKEND_ORIGIN = 'http://127.0.0.1:8000';

  // آدرس کامل یک عکس آپلودشده (مسیر نسبی media/... که بک‌اند برمی‌گردونه)
  function imgUrl(path){
    if(!path) return '';
    return /^https?:\/\//.test(path) ? path : (BACKEND_ORIGIN + path);
  }

  // تصویر کوچک برای هر ردیف لیست - اگر عکس داشت نشونش بده، وگرنه جای خالی
  function thumbHtml(item){
    if(item && item.image){
      return '<img src="' + imgUrl(item.image) + '" alt="" class="lr-thumb-img">';
    }
    return '<span class="lr-thumb-empty">بدون عکس</span>';
  }

  // فقط «مدیرکل»، «مدیر شعبه» و «خبرنگار» اجازه ورود به این پنل رو دارن؛ «عضو» فقط خواننده‌ست
  if(!authData || ['admin', 'branch_manager', 'reporter'].indexOf(authData.role) === -1){
    window.location.href = 'login.html';
    return;
  }

  if(authData.user){
    document.getElementById('adminName').textContent = authData.user;
    document.getElementById('adminAvatar').textContent = authData.user.charAt(0).toUpperCase();
  }

  var ROLE_TITLES = { admin: 'مدیرکل', branch_manager: 'مدیر شعبه', reporter: 'خبرنگار' };
  var roleTitleEl = document.querySelector('.admin-user .role');
  if(roleTitleEl) roleTitleEl.textContent = ROLE_TITLES[authData.role] || 'مدیر محتوا';

  var IS_ADMIN = authData.role === 'admin';
  var IS_BRANCH_MANAGER = authData.role === 'branch_manager';
  var IS_REPORTER = authData.role === 'reporter';
  var MY_BRANCH = authData.branch || '';

  // «بازگشت به سایت اصلی» برای مدیر شعبه/خبرنگار باید صفحه اصلی *شعبه‌ی خودشون* رو باز کنه،
  // نه صفحه اصلی سراسری - تا مثلاً مدیر شعبه کرج پیش‌فرض اخبار یزد رو نبینه.
  var backToSiteLink = document.querySelector('a.hm-item[href="index.html"]');
  if(backToSiteLink && !IS_ADMIN && MY_BRANCH){
    backToSiteLink.href = 'index.html?branch=' + encodeURIComponent(MY_BRANCH);
  }

  // «مدیر شعبه» فقط اسلایدها و اخبار شعبه‌ی خودشو می‌بینه/می‌سازه؛ بخش‌های ساختاری سایت
  // (سرویس‌ها/پیوندها/آخرین اخبار/اسلایدشوی اخبار) که سراسری و مخصوص مدیرکله مخفی می‌شن.
  // «خبرنگار» فقط بخش «ارسال خبر» رو می‌بینه.
  if(IS_BRANCH_MANAGER){
    document.body.classList.add('role-branch-manager');
    ['services', 'links', 'latestNews', 'newsSlider'].forEach(function(key){
      var card = document.querySelector('.mgmt-card[data-target="' + key + '"]');
      if(card) card.style.display = 'none';
    });
  }
  if(IS_REPORTER){
    document.body.classList.add('role-reporter');
    // خبرنگار الان هم به «مدیریت اسلایدشو» و هم به «ارسال خبر» دسترسی داره (فقط شعبه‌ی خودش)
    ['services', 'links', 'latestNews', 'newsSlider'].forEach(function(key){
      var card = document.querySelector('.mgmt-card[data-target="' + key + '"]');
      if(card) card.style.display = 'none';
    });
  }

  function doLogout(){
    sessionStorage.removeItem('hk_admin_auth');
    localStorage.removeItem('hk_admin_auth');
    window.location.href = 'login.html';
  }
  document.getElementById('logoutBtn').addEventListener('click', doLogout);
  document.getElementById('hmLogout').addEventListener('click', doLogout);

  /* ============================================================
     HAMBURGER MENU
     ============================================================ */
  var hamburgerBtn = document.getElementById('hamburgerBtn');
  var hamburgerMenu = document.getElementById('hamburgerMenu');

  // مدیریت کاربران («افزودن ادمین») برای «مدیرکل» و «مدیر شعبه» هست (مدیر شعبه فقط خبرنگار می‌سازه)؛
  // «خبرنگار» اصلاً بهش دسترسی نداره.
  if(IS_REPORTER){
    hamburgerMenu.querySelectorAll('[data-action^="users-"]').forEach(function(btn){ btn.style.display = 'none'; });
    hamburgerMenu.querySelector('.hm-group-title').style.display = 'none';
  } else if(IS_BRANCH_MANAGER){
    hamburgerMenu.querySelector('.hm-group-title').textContent = 'مدیریت ادمین‌های شعبه';
    var addBtn = hamburgerMenu.querySelector('[data-action="users-add"] span');
    if(addBtn) addBtn.textContent = 'افزودن ادمین';
  }

  hamburgerBtn.addEventListener('click', function(e){
    e.stopPropagation();
    hamburgerMenu.classList.toggle('open');
  });
  document.addEventListener('click', function(e){
    if(!hamburgerMenu.contains(e.target) && e.target !== hamburgerBtn){
      hamburgerMenu.classList.remove('open');
    }
  });
  hamburgerMenu.querySelectorAll('[data-action^="users-"]').forEach(function(btn){
    btn.addEventListener('click', function(){
      hamburgerMenu.classList.remove('open');
      showSection('users');
      var action = btn.getAttribute('data-action');
      setTimeout(function(){
        if(action === 'users-add'){
          var f = document.getElementById('userAddForm');
          if(f) f.scrollIntoView({ behavior:'smooth', block:'start' });
        } else if(action === 'users-view'){
          var v = document.getElementById('userViewPanel');
          if(v) v.scrollIntoView({ behavior:'smooth', block:'start' });
        } else {
          var l = document.getElementById('userListWrap');
          if(l) l.scrollIntoView({ behavior:'smooth', block:'start' });
        }
      }, 50);
    });
  });

  /* ============================================================
     TOAST
     ============================================================ */
  var toastEl = document.getElementById('toast');
  var toastTimer = null;
  function toast(msg){
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearInterval(toastTimer);
    toastTimer = setTimeout(function(){ toastEl.classList.remove('show'); }, 2200);
  }

  /* ============================================================
     API HELPERS (real backend - Django REST) - جایگزین localStorage
     ============================================================ */
  // هر بخش پنل ادمین به یک اندپوینت واقعی تو بک‌اند وصله
  var ENDPOINTS = {
    services:   'services',
    mainSlider: 'main-slides',
    latestNews: 'latest-news',
    links:      'links',
    newsSlider: 'news-slides',
    publish:    'articles'
  };

  function apiHeaders(withJson){
    var h = { 'Authorization': 'Token ' + authData.token };
    if(withJson) h['Content-Type'] = 'application/json';
    return h;
  }

  // فهرست همه‌ی رکوردهای یک بخش رو از بک‌اند می‌گیره
  function apiList(key){
    return fetch(API_BASE + '/' + ENDPOINTS[key] + '/', { headers: apiHeaders(false) })
      .then(function(res){
        if(!res.ok) throw new Error('list-failed');
        return res.json();
      })
      .then(function(data){ return Array.isArray(data) ? data : (data.results || []); })
      .catch(function(){ return []; });
  }

  // ساخت رکورد جدید - اگر body شامل فایل (عکس) باشه به‌صورت خودکار multipart/form-data می‌فرسته
  function apiCreate(key, body){
    var hasFile = false;
    Object.keys(body || {}).forEach(function(k){
      if(body[k] instanceof File) hasFile = true;
    });

    var fetchOptions;
    if(hasFile){
      var fd = new FormData();
      Object.keys(body).forEach(function(k){
        var v = body[k];
        if(v === undefined || v === null) return;
        // فایل خالی (یعنی کاربر عکسی انتخاب نکرده) رو نفرست
        if(v instanceof File && v.size === 0) return;
        fd.append(k, v);
      });
      // موقع استفاده از FormData نباید Content-Type رو دستی ست کنیم؛ خود مرورگر با boundary درستش می‌سازه
      fetchOptions = { method: 'POST', headers: apiHeaders(false), body: fd };
    } else {
      fetchOptions = { method: 'POST', headers: apiHeaders(true), body: JSON.stringify(body) };
    }

    return fetch(API_BASE + '/' + ENDPOINTS[key] + '/', fetchOptions).then(function(res){
      return res.json().then(function(d){ return { ok: res.ok, d: d }; })
        .catch(function(){ return { ok: res.ok, d: {} }; });
    }).catch(function(){
      // fetch خودش رد شد یعنی اصلاً به سرور وصل نشدیم (بک‌اند خاموشه یا آدرسش اشتباهه)
      return { ok: false, d: { detail: 'ارتباط با سرور برقرار نشد. مطمئن شو بک‌اند جنگو (python manage.py runserver) روشن و در حال اجراست.' } };
    });
  }

  // حذف رکورد
  function apiDelete(key, id){
    return fetch(API_BASE + '/' + ENDPOINTS[key] + '/' + id + '/', {
      method: 'DELETE', headers: apiHeaders(false)
    }).then(function(res){ return res.ok || res.status === 204; })
      .catch(function(){
        toast('ارتباط با سرور برقرار نشد. مطمئن شو بک‌اند روشنه.');
        return false;
      });
  }

  // دسته‌ی موضوعی (کارگری/بازنشستگان/...) برای همه نقش‌ها یکسانه؛ چیزی که محدود می‌شه «شعبه»‌ست،
  // نه دسته‌ی موضوعی - و شعبه‌ی مدیر شعبه/خبرنگار خودکار توسط بک‌اند تعیین می‌شه.
  var CATEGORY_OPTIONS = ['کارگری','بازنشستگان','آموزشی','گردشگری','فرهنگی','تعاونی مصرف'];

  /* ============================================================
     NAVIGATION: dashboard <-> section
     ============================================================ */
  var dashboardView = document.getElementById('dashboardView');
  var backRow = document.getElementById('backRow');
  var backBtn = document.getElementById('backBtn');
  var allSections = document.querySelectorAll('.section-view');

  function showDashboard(){
    dashboardView.style.display = 'flex';
    backRow.classList.remove('show');
    allSections.forEach(function(s){ s.classList.remove('show'); });
    updateCounts();
    window.scrollTo({ top:0, behavior:'smooth' });
  }

  function showSection(key){
    dashboardView.style.display = 'none';
    backRow.classList.add('show');
    allSections.forEach(function(s){ s.classList.remove('show'); });
    var el = document.getElementById('section-' + key);
    el.classList.add('show');
    renderers[key]();
    window.scrollTo({ top:0, behavior:'smooth' });
  }

  document.querySelectorAll('.mgmt-card').forEach(function(card){
    card.addEventListener('click', function(){
      showSection(card.getAttribute('data-target'));
    });
  });
  backBtn.addEventListener('click', showDashboard);

  function updateCounts(){
    ['services','mainSlider','latestNews','links','newsSlider','publish'].forEach(function(key){
      var el = document.querySelector('[data-count="' + key + '"]');
      if(!el) return;
      apiList(key).then(function(list){
        el.textContent = toFa(list.length) + ' مورد';
      });
    });
  }

  function toFa(n){
    var map = {'0':'۰','1':'۱','2':'۲','3':'۳','4':'۴','5':'۵','6':'۶','7':'۷','8':'۸','9':'۹'};
    return String(n).replace(/[0-9]/g, function(d){ return map[d]; });
  }

  function escapeHtml(str){
    return String(str || '').replace(/[&<>"']/g, function(c){
      return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c];
    });
  }

  function categoryOptionsHtml(selected){
    return CATEGORY_OPTIONS.map(function(c){
      return '<option value="' + c + '"' + (c === selected ? ' selected' : '') + '>' + c + '</option>';
    }).join('');
  }

  /* ============================================================
     SECTION: مدیریت سرویس‌ها (services)
     ============================================================ */
  function renderServices(){
    var host = document.getElementById('section-services');
    host.innerHTML =
      '<div class="section-head"><div><h2>مدیریت سرویس‌ها</h2><div class="sub">سرویس‌ها و دسته‌هایی که در نوار بالای صفحه نخست نمایش داده می‌شوند</div></div></div>' +
      '<div class="panel">' +
        '<h3>افزودن سرویس جدید</h3>' +
        '<form id="frmServices">' +
          '<div class="form-grid">' +
            '<div class="f-field"><label>عنوان سرویس</label><input type="text" id="svcTitle" placeholder="مثلاً: کارگری" required></div>' +
            '<div class="f-field"><label>لینک مقصد</label><input type="text" id="svcLink" placeholder="category.html?cat=..." required></div>' +
            '<div class="f-field"><label>رنگ برجسته</label>' +
              '<select id="svcAccent"><option value="teal">تیل (اصلی)</option><option value="gold">طلایی</option></select>' +
            '</div>' +
            '<div class="f-field"><label>عکس (اختیاری)</label><input type="file" id="svcImage" accept="image/*"></div>' +
          '</div>' +
          '<div class="form-actions"><button type="submit" class="btn btn-primary">افزودن سرویس</button></div>' +
        '</form>' +
      '</div>' +
      '<div class="list-wrap" id="svcList"><div class="list-empty">در حال بارگذاری...</div></div>';

    function paint(){
      var wrap = document.getElementById('svcList');
      apiList('services').then(function(list){
        if(!list.length){ wrap.innerHTML = '<div class="list-empty">هنوز سرویسی اضافه نشده است.</div>'; updateCounts(); return; }
        wrap.innerHTML = list.map(function(item){
          return '<div class="list-row" data-accent="' + item.accent + '" data-id="' + item.id + '">' +
            '<div class="lr-thumb">' + thumbHtml(item) + '</div>' +
            '<span class="lr-badge">' + (item.accent === 'gold' ? 'طلایی' : 'تیل') + '</span>' +
            '<div class="lr-body"><h4>' + escapeHtml(item.title) + '</h4><p>' + escapeHtml(item.link) + '</p></div>' +
            '<div class="lr-actions">' +
              '<button class="icon-btn danger" data-del="' + item.id + '" title="حذف">' + trashIcon() + '</button>' +
            '</div>' +
          '</div>';
        }).join('');
        wrap.querySelectorAll('[data-del]').forEach(function(btn){
          btn.addEventListener('click', function(){
            apiDelete('services', btn.getAttribute('data-del')).then(function(ok){
              toast(ok ? 'سرویس حذف شد.' : 'خطا در حذف سرویس.');
              paint();
            });
          });
        });
        updateCounts();
      });
    }

    document.getElementById('frmServices').addEventListener('submit', function(e){
      e.preventDefault();
      var title = document.getElementById('svcTitle').value.trim();
      var link = document.getElementById('svcLink').value.trim();
      var accent = document.getElementById('svcAccent').value;
      var imageFile = document.getElementById('svcImage').files[0];
      if(!title || !link) return;
      apiCreate('services', { title:title, link:link, accent:accent, image:imageFile }).then(function(r){
        if(!r.ok){ toast((r.d && (r.d.detail || r.d.title || r.d.link)) || 'خطا در افزودن سرویس.'); return; }
        e.target.reset();
        toast('سرویس با موفقیت اضافه شد.');
        paint();
      });
    });

    paint();
  }

  /* ============================================================
     SECTION: مدیریت اسلایدشو (main homepage slider)
     ============================================================ */
  function renderMainSlider(){
    var host = document.getElementById('section-mainSlider');
    var branchNote = !IS_ADMIN && MY_BRANCH ? ' — فقط شعبه‌ی ' + escapeHtml(MY_BRANCH) : '';
    host.innerHTML =
      '<div class="section-head"><div><h2>مدیریت اسلایدشو</h2><div class="sub">اسلایدهای بزرگ صفحه نخست و کادرهای «لید» (که زیر خبر و در صفحه دسته نمایش داده می‌شن)' + branchNote + '</div></div></div>' +
      '<div class="panel">' +
        '<h3>افزودن مورد جدید</h3>' +
        '<form id="frmSlider">' +
          '<div class="form-grid">' +
            '<div class="f-field"><label>نوع</label><select id="slKind">' +
              '<option value="slide">اسلاید اصلی (اسلایدشو بالای صفحه)</option>' +
              '<option value="lead">لید (کادر عکس‌دار زیر خبر / صفحه دسته)</option>' +
            '</select></div>' +
            '<div class="f-field"><label>دسته خبر</label><select id="slCat">' + categoryOptionsHtml() + '</select></div>' +
            '<div class="f-field"><label>تاریخ</label><input type="text" id="slDate" placeholder="مثلاً: ۲۹ تیر ۱۴۰۴" required></div>' +
            '<div class="f-field full"><label>عنوان خبر</label><input type="text" id="slTitle" placeholder="عنوان اسلاید" required></div>' +
            '<div class="f-field"><label>رنگ برجسته</label><select id="slAccent"><option value="teal">تیل</option><option value="gold">طلایی</option></select></div>' +
            '<div class="f-field"><label>عکس (اختیاری)</label><input type="file" id="slImage" accept="image/*"></div>' +
            (IS_ADMIN
              ? '<div class="f-field"><label>شعبه (اختیاری)</label><input type="text" id="slBranch" placeholder="خالی = سراسری، یا مثلاً: یزد"></div>'
              : '') +
            '<div class="f-field full"><label>متن کامل (اختیاری)</label><textarea id="slBody" rows="4" placeholder="در صورت نیاز، متن کامل مرتبط با این اسلاید را بنویسید..."></textarea></div>' +
          '</div>' +
          '<div class="form-actions"><button type="submit" class="btn btn-primary">افزودن اسلاید</button></div>' +
        '</form>' +
      '</div>' +
      '<div class="list-wrap" id="slList"><div class="list-empty">در حال بارگذاری...</div></div>';

    function paint(){
      var wrap = document.getElementById('slList');
      apiList('mainSlider').then(function(list){
        if(!list.length){ wrap.innerHTML = '<div class="list-empty">هنوز اسلایدی اضافه نشده است.</div>'; updateCounts(); return; }
        wrap.innerHTML = list.map(function(item){
          var kindLabel = item.kind === 'lead' ? 'لید' : 'اسلاید';
          var branchLabel = IS_ADMIN && item.branch ? ' · شعبه ' + escapeHtml(item.branch) : '';
          return '<div class="list-row" data-accent="' + item.accent + '">' +
            '<div class="lr-thumb">' + thumbHtml(item) + '</div>' +
            '<span class="lr-badge">' + escapeHtml(kindLabel) + ' · ' + escapeHtml(item.category) + branchLabel + '</span>' +
            '<div class="lr-body"><h4>' + escapeHtml(item.title) + '</h4></div>' +
            '<span class="lr-meta">' + escapeHtml(item.date) + '</span>' +
            '<div class="lr-actions"><button class="icon-btn danger" data-del="' + item.id + '" title="حذف">' + trashIcon() + '</button></div>' +
          '</div>';
        }).join('');
        wrap.querySelectorAll('[data-del]').forEach(function(btn){
          btn.addEventListener('click', function(){
            apiDelete('mainSlider', btn.getAttribute('data-del')).then(function(ok){
              toast(ok ? 'مورد حذف شد.' : 'خطا در حذف.');
              paint();
            });
          });
        });
        updateCounts();
      });
    }

    document.getElementById('frmSlider').addEventListener('submit', function(e){
      e.preventDefault();
      var title = document.getElementById('slTitle').value.trim();
      var date = document.getElementById('slDate').value.trim();
      if(!title || !date) return;
      var branchInput = document.getElementById('slBranch');
      apiCreate('mainSlider', {
        kind: document.getElementById('slKind').value,
        category: document.getElementById('slCat').value,
        title: title,
        date: date,
        accent: document.getElementById('slAccent').value,
        image: document.getElementById('slImage').files[0],
        body: document.getElementById('slBody').value.trim(),
        branch: branchInput ? branchInput.value.trim() : undefined
      }).then(function(r){
        if(!r.ok){ toast((r.d && (r.d.detail || r.d.title || r.d.category || r.d.date)) || 'خطا در افزودن.'); return; }
        e.target.reset();
        toast('با موفقیت اضافه شد.');
        paint();
      });
    });

    paint();
  }

  /* ============================================================
     SECTION: مدیریت آخرین اخبار (latest news)
     ============================================================ */
  function renderLatestNews(){
    var host = document.getElementById('section-latestNews');
    host.innerHTML =
      '<div class="section-head"><div><h2>مدیریت آخرین اخبار</h2><div class="sub">فهرست کارت‌های خبری نمایش‌داده‌شده در بخش‌های موضوعی صفحه نخست</div></div></div>' +
      '<div class="panel">' +
        '<h3>افزودن خبر جدید</h3>' +
        '<form id="frmNews">' +
          '<div class="form-grid">' +
            '<div class="f-field"><label>دسته خبر</label><select id="nwCat">' + categoryOptionsHtml() + '</select></div>' +
            '<div class="f-field"><label>تاریخ</label><input type="text" id="nwDate" placeholder="مثلاً: ۲۹ تیر ۱۴۰۴" required></div>' +
            '<div class="f-field full"><label>عنوان خبر</label><input type="text" id="nwTitle" placeholder="عنوان خبر" required></div>' +
            '<div class="f-field"><label>رنگ برجسته</label><select id="nwAccent"><option value="teal">تیل</option><option value="gold">طلایی</option></select></div>' +
            '<div class="f-field"><label>عکس (اختیاری)</label><input type="file" id="nwImage" accept="image/*"></div>' +
            '<div class="f-field full"><label>متن کامل (اختیاری)</label><textarea id="nwBody" rows="4" placeholder="در صورت نیاز، متن کامل این خبر را بنویسید..."></textarea></div>' +
          '</div>' +
          '<div class="form-actions"><button type="submit" class="btn btn-primary">افزودن خبر</button></div>' +
        '</form>' +
      '</div>' +
      '<div class="list-wrap" id="nwList"><div class="list-empty">در حال بارگذاری...</div></div>';

    function paint(){
      var wrap = document.getElementById('nwList');
      apiList('latestNews').then(function(list){
        if(!list.length){ wrap.innerHTML = '<div class="list-empty">هنوز خبری اضافه نشده است.</div>'; updateCounts(); return; }
        wrap.innerHTML = list.map(function(item){
          return '<div class="list-row" data-accent="' + item.accent + '">' +
            '<div class="lr-thumb">' + thumbHtml(item) + '</div>' +
            '<span class="lr-badge">' + escapeHtml(item.category) + '</span>' +
            '<div class="lr-body"><h4>' + escapeHtml(item.title) + '</h4></div>' +
            '<span class="lr-meta">' + escapeHtml(item.date) + '</span>' +
            '<div class="lr-actions"><button class="icon-btn danger" data-del="' + item.id + '" title="حذف">' + trashIcon() + '</button></div>' +
          '</div>';
        }).join('');
        wrap.querySelectorAll('[data-del]').forEach(function(btn){
          btn.addEventListener('click', function(){
            apiDelete('latestNews', btn.getAttribute('data-del')).then(function(ok){
              toast(ok ? 'خبر حذف شد.' : 'خطا در حذف خبر.');
              paint();
            });
          });
        });
        updateCounts();
      });
    }

    document.getElementById('frmNews').addEventListener('submit', function(e){
      e.preventDefault();
      var title = document.getElementById('nwTitle').value.trim();
      var date = document.getElementById('nwDate').value.trim();
      if(!title || !date) return;
      apiCreate('latestNews', {
        category: document.getElementById('nwCat').value,
        title: title,
        date: date,
        accent: document.getElementById('nwAccent').value,
        image: document.getElementById('nwImage').files[0],
        body: document.getElementById('nwBody').value.trim()
      }).then(function(r){
        if(!r.ok){ toast((r.d && (r.d.detail || r.d.title || r.d.category || r.d.date)) || 'خطا در افزودن خبر.'); return; }
        e.target.reset();
        toast('خبر با موفقیت اضافه شد.');
        paint();
      });
    });

    paint();
  }

  /* ============================================================
     SECTION: مدیریت پیوندها (links)
     ============================================================ */
  function renderLinks(){
    var host = document.getElementById('section-links');
    host.innerHTML =
      '<div class="section-head"><div><h2>مدیریت پیوندها</h2><div class="sub">لینک‌های سریع و سامانه‌های مرتبط نمایش‌داده‌شده در فوتر سایت</div></div></div>' +
      '<div class="panel">' +
        '<h3>افزودن پیوند جدید</h3>' +
        '<form id="frmLinks">' +
          '<div class="form-grid">' +
            '<div class="f-field"><label>عنوان پیوند</label><input type="text" id="lkTitle" placeholder="مثلاً: سامانه سرا" required></div>' +
            '<div class="f-field"><label>آدرس (URL)</label><input type="text" id="lkUrl" placeholder="https:// یا #" required></div>' +
            '<div class="f-field"><label>گروه نمایش</label><select id="lkGroup"><option value="دسترسی سریع">دسترسی سریع</option><option value="سامانه‌های مرتبط">سامانه‌های مرتبط</option></select></div>' +
            '<div class="f-field"><label>عکس / آیکون (اختیاری)</label><input type="file" id="lkImage" accept="image/*"></div>' +
          '</div>' +
          '<div class="form-actions"><button type="submit" class="btn btn-primary">افزودن پیوند</button></div>' +
        '</form>' +
      '</div>' +
      '<div class="list-wrap" id="lkList"><div class="list-empty">در حال بارگذاری...</div></div>';

    function paint(){
      var wrap = document.getElementById('lkList');
      apiList('links').then(function(list){
        if(!list.length){ wrap.innerHTML = '<div class="list-empty">هنوز پیوندی اضافه نشده است.</div>'; updateCounts(); return; }
        wrap.innerHTML = list.map(function(item){
          return '<div class="list-row">' +
            '<div class="lr-thumb">' + thumbHtml(item) + '</div>' +
            '<span class="lr-badge">' + escapeHtml(item.group) + '</span>' +
            '<div class="lr-body"><h4>' + escapeHtml(item.title) + '</h4><p>' + escapeHtml(item.url) + '</p></div>' +
            '<div class="lr-actions"><button class="icon-btn danger" data-del="' + item.id + '" title="حذف">' + trashIcon() + '</button></div>' +
          '</div>';
        }).join('');
        wrap.querySelectorAll('[data-del]').forEach(function(btn){
          btn.addEventListener('click', function(){
            apiDelete('links', btn.getAttribute('data-del')).then(function(ok){
              toast(ok ? 'پیوند حذف شد.' : 'خطا در حذف پیوند.');
              paint();
            });
          });
        });
        updateCounts();
      });
    }

    document.getElementById('frmLinks').addEventListener('submit', function(e){
      e.preventDefault();
      var title = document.getElementById('lkTitle').value.trim();
      var url = document.getElementById('lkUrl').value.trim();
      if(!title || !url) return;
      apiCreate('links', {
        title:title,
        url:url,
        group: document.getElementById('lkGroup').value,
        image: document.getElementById('lkImage').files[0]
      }).then(function(r){
        if(!r.ok){ toast((r.d && (r.d.detail || r.d.title || r.d.url)) || 'خطا در افزودن پیوند.'); return; }
        e.target.reset();
        toast('پیوند با موفقیت اضافه شد.');
        paint();
      });
    });

    paint();
  }

  /* ============================================================
     SECTION: مدیریت اسلایدشو اخبار (per-category mini sliders)
     ============================================================ */
  function renderNewsSlider(){
    var host = document.getElementById('section-newsSlider');
    host.innerHTML =
      '<div class="section-head"><div><h2>مدیریت اسلایدشو اخبار</h2><div class="sub">اسلایدرهای کوچک اخبار به تفکیک هر موضوع در صفحه نخست</div></div></div>' +
      '<div class="panel">' +
        '<h3>افزودن آیتم جدید</h3>' +
        '<form id="frmNs">' +
          '<div class="form-grid">' +
            '<div class="f-field"><label>دسته موضوعی</label><select id="nsCat">' + categoryOptionsHtml() + '</select></div>' +
            '<div class="f-field"><label>تاریخ</label><input type="text" id="nsDate" placeholder="مثلاً: ۲۹ تیر ۱۴۰۴" required></div>' +
            '<div class="f-field full"><label>عنوان</label><input type="text" id="nsTitle" placeholder="عنوان خبر در اسلایدر" required></div>' +
            '<div class="f-field"><label>رنگ برجسته</label><select id="nsAccent"><option value="teal">تیل</option><option value="gold">طلایی</option></select></div>' +
            '<div class="f-field"><label>عکس (اختیاری)</label><input type="file" id="nsImage" accept="image/*"></div>' +
            '<div class="f-field full"><label>متن کامل (اختیاری)</label><textarea id="nsBody" rows="4" placeholder="در صورت نیاز، متن کامل این آیتم را بنویسید..."></textarea></div>' +
          '</div>' +
          '<div class="form-actions"><button type="submit" class="btn btn-primary">افزودن آیتم</button></div>' +
        '</form>' +
      '</div>' +
      '<div class="list-wrap" id="nsList"><div class="list-empty">در حال بارگذاری...</div></div>';

    function paint(){
      var wrap = document.getElementById('nsList');
      apiList('newsSlider').then(function(list){
        if(!list.length){ wrap.innerHTML = '<div class="list-empty">هنوز آیتمی اضافه نشده است.</div>'; updateCounts(); return; }
        wrap.innerHTML = list.map(function(item){
          return '<div class="list-row" data-accent="' + item.accent + '">' +
            '<div class="lr-thumb">' + thumbHtml(item) + '</div>' +
            '<span class="lr-badge">' + escapeHtml(item.category) + '</span>' +
            '<div class="lr-body"><h4>' + escapeHtml(item.title) + '</h4></div>' +
            '<span class="lr-meta">' + escapeHtml(item.date) + '</span>' +
            '<div class="lr-actions"><button class="icon-btn danger" data-del="' + item.id + '" title="حذف">' + trashIcon() + '</button></div>' +
          '</div>';
        }).join('');
        wrap.querySelectorAll('[data-del]').forEach(function(btn){
          btn.addEventListener('click', function(){
            apiDelete('newsSlider', btn.getAttribute('data-del')).then(function(ok){
              toast(ok ? 'آیتم حذف شد.' : 'خطا در حذف آیتم.');
              paint();
            });
          });
        });
        updateCounts();
      });
    }

    document.getElementById('frmNs').addEventListener('submit', function(e){
      e.preventDefault();
      var title = document.getElementById('nsTitle').value.trim();
      var date = document.getElementById('nsDate').value.trim();
      if(!title || !date) return;
      apiCreate('newsSlider', {
        category: document.getElementById('nsCat').value,
        title: title,
        date: date,
        accent: document.getElementById('nsAccent').value,
        image: document.getElementById('nsImage').files[0],
        body: document.getElementById('nsBody').value.trim()
      }).then(function(r){
        if(!r.ok){ toast((r.d && (r.d.detail || r.d.title || r.d.category || r.d.date)) || 'خطا در افزودن آیتم.'); return; }
        e.target.reset();
        toast('آیتم با موفقیت اضافه شد.');
        paint();
      });
    });

    paint();
  }

  /* ============================================================
     SECTION: ارسال خبر (publish a new article)
     ============================================================ */
  function renderPublish(){
    var host = document.getElementById('section-publish');
    var branchNote = !IS_ADMIN && MY_BRANCH ? ' — فقط شعبه‌ی ' + escapeHtml(MY_BRANCH) : '';
    host.innerHTML =
      '<div class="section-head"><div><h2>ارسال خبر</h2><div class="sub">نوشتن و انتشار خبر تازه در پایگاه خبری' + branchNote + '</div></div></div>' +
      '<div class="panel">' +
        '<h3>خبر جدید</h3>' +
        '<form id="frmPublish">' +
          '<div class="form-grid">' +
            '<div class="f-field full"><label>عنوان خبر</label><input type="text" id="pbTitle" placeholder="عنوان کامل خبر" required></div>' +
            '<div class="f-field"><label>دسته خبر</label><select id="pbCat">' + categoryOptionsHtml() + '</select></div>' +
            '<div class="f-field"><label>تاریخ انتشار</label><input type="text" id="pbDate" placeholder="مثلاً: ۲۹ تیر ۱۴۰۴" required></div>' +
            '<div class="f-field full"><label>عکس خبر (اختیاری)</label><input type="file" id="pbImage" accept="image/*"></div>' +
            (IS_ADMIN
              ? '<div class="f-field"><label>شعبه (اختیاری)</label><input type="text" id="pbBranch" placeholder="خالی = سراسری، یا مثلاً: یزد"></div>'
              : '') +
            '<div class="f-field full"><label>متن کامل خبر</label><textarea id="pbBody" rows="6" placeholder="متن کامل خبر را این‌جا بنویسید..." required></textarea></div>' +
          '</div>' +
          '<div class="form-actions">' +
            '<button type="submit" class="btn btn-primary">انتشار خبر</button>' +
            '<button type="button" class="btn btn-ghost" id="pbDraft">ذخیره پیش‌نویس</button>' +
          '</div>' +
        '</form>' +
      '</div>' +
      '<div class="panel">' +
        '<h3>اخبار ارسال‌شده</h3>' +
        '<div class="list-wrap" id="pbList"><div class="list-empty">در حال بارگذاری...</div></div>' +
      '</div>';

    function paint(){
      var wrap = document.getElementById('pbList');
      // بدون پارامتر status: بک‌اند برای مدیرکل/مدیر شعبه/خبرنگار هم پیش‌نویس و هم منتشرشده رو برمی‌گردونه
      // (و برای مدیر شعبه/خبرنگار خودکار فقط اخبار شعبه‌ی خودشون)
      fetch(API_BASE + '/' + ENDPOINTS.publish + '/', { headers: apiHeaders(false) })
        .then(function(res){ return res.ok ? res.json() : []; })
        .then(function(data){
          var list = Array.isArray(data) ? data : (data.results || []);
          if(!list.length){ wrap.innerHTML = '<div class="list-empty">هنوز خبری ارسال نشده است.</div>'; updateCounts(); return; }
          wrap.innerHTML = list.map(function(item){
            var branchLabel = IS_ADMIN && item.branch ? ' · شعبه ' + escapeHtml(item.branch) : '';
            return '<div class="list-row" data-accent="' + (item.status === 'published' ? 'gold' : 'teal') + '">' +
              '<div class="lr-thumb">' + thumbHtml(item) + '</div>' +
              '<span class="lr-badge">' + (item.status === 'published' ? 'منتشرشده' : 'پیش‌نویس') + branchLabel + '</span>' +
              '<div class="lr-body"><h4>' + escapeHtml(item.title) + '</h4><p>' + escapeHtml(item.category) + ' — ' + escapeHtml(item.body || '') + '</p></div>' +
              '<span class="lr-meta">' + escapeHtml(item.date) + '</span>' +
              '<div class="lr-actions"><button class="icon-btn danger" data-del="' + item.id + '" title="حذف">' + trashIcon() + '</button></div>' +
            '</div>';
          }).join('');
          wrap.querySelectorAll('[data-del]').forEach(function(btn){
            btn.addEventListener('click', function(){
              apiDelete('publish', btn.getAttribute('data-del')).then(function(ok){
                toast(ok ? 'مورد حذف شد.' : 'خطا در حذف.');
                paint();
              });
            });
          });
          updateCounts();
        });
    }

    function addEntry(status){
      var title = document.getElementById('pbTitle').value.trim();
      var date = document.getElementById('pbDate').value.trim();
      var body = document.getElementById('pbBody').value.trim();
      if(!title || !date || !body){ toast('لطفاً همه فیلدهای لازم را پر کنید.'); return; }
      var branchInput = document.getElementById('pbBranch');
      apiCreate('publish', {
        title: title,
        category: document.getElementById('pbCat').value,
        date: date,
        body: body,
        status: status,
        image: document.getElementById('pbImage').files[0],
        branch: branchInput ? branchInput.value.trim() : undefined
      }).then(function(r){
        if(!r.ok){ toast((r.d && (r.d.detail || r.d.title || r.d.category || r.d.date || r.d.body)) || 'خطا در ثبت خبر.'); return; }
        document.getElementById('frmPublish').reset();
        toast(status === 'published' ? 'خبر با موفقیت منتشر شد.' : 'پیش‌نویس ذخیره شد.');
        paint();
      });
    }

    document.getElementById('frmPublish').addEventListener('submit', function(e){
      e.preventDefault();
      addEntry('published');
    });
    document.getElementById('pbDraft').addEventListener('click', function(){
      addEntry('draft');
    });

    paint();
  }

  /* ============================================================
     SECTION: مدیریت کاربران (واقعی - از طریق API بک‌اند)
     ============================================================ */
  var ROLE_LABELS = { admin: 'مدیرکل', branch_manager: 'مدیر شعبه', reporter: 'خبرنگار' };

  function renderUsers(){
    var host = document.getElementById('section-users');

    // مدیرکل می‌تونه هر سه نقش رو با هر شعبه‌ای بسازه؛ مدیر شعبه فقط خبرنگار برای شعبه‌ی خودش می‌سازه
    var roleFieldHtml = IS_ADMIN
      ? '<div class="f-field"><label>نقش</label>' +
          '<select id="uaRole">' +
            '<option value="reporter" selected>خبرنگار (فقط ثبت/ویرایش خبر)</option>' +
            '<option value="branch_manager">مدیر شعبه (اسلاید + خبر شعبه)</option>' +
            '<option value="admin">مدیرکل (دسترسی کامل)</option>' +
          '</select>' +
        '</div>' +
        '<div class="f-field"><label>شعبه (برای مدیر شعبه/خبرنگار)</label><input type="text" id="uaBranch" placeholder="مثلاً: یزد"></div>'
      : '<div class="f-field full"><div class="sub" style="color:var(--text-mute);font-size:12.5px;">' +
          'این ادمین به‌صورت خودکار برای شعبه‌ی «' + escapeHtml(MY_BRANCH || '—') + '» ساخته می‌شود (دسترسی: ثبت/ویرایش خبر و اسلاید همین شعبه).' +
        '</div></div>';

    var sectionSub = IS_ADMIN
      ? 'افزودن، ویرایش و غیرفعال کردن کاربران (مدیرکل / مدیر شعبه / خبرنگار)'
      : 'افزودن، ویرایش و غیرفعال کردن ادمین‌های شعبه‌ی «' + escapeHtml(MY_BRANCH || '—') + '» — مدیر شعبه فقط ادمین‌های خودش را می‌بیند؛ نه ادمین‌های مدیرکل و نه شعبه‌های دیگر.';

    host.innerHTML =
      '<div class="section-head"><div><h2>مدیریت کاربران</h2><div class="sub">' + sectionSub + '</div></div></div>' +
      '<div class="panel" id="userAddPanel">' +
        '<h3>' + (IS_ADMIN ? 'افزودن کاربر جدید' : 'افزودن ادمین جدید') + '</h3>' +
        '<form id="userAddForm">' +
          '<div class="form-grid">' +
            '<div class="f-field"><label>نام کاربری</label><input type="text" id="uaUsername" required></div>' +
            '<div class="f-field"><label>رمز عبور</label><input type="password" id="uaPassword" required></div>' +
            roleFieldHtml +
          '</div>' +
          '<div class="form-actions"><button type="submit" class="btn btn-primary">' + (IS_ADMIN ? 'افزودن کاربر' : 'افزودن ادمین') + '</button></div>' +
        '</form>' +
      '</div>' +
      '<div class="panel" id="userViewPanel">' +
        '<h3>نمایش کاربر</h3>' +
        '<div class="sub" style="color:var(--text-mute);font-size:12.5px;margin-bottom:12px;">فهرست همه کاربرهایی که تاکنون اضافه شده‌اند (فقط نمایش)</div>' +
        '<div class="form-grid">' +
          '<div class="f-field full"><label>جستجوی نام کاربری</label><input type="text" id="uvSearch" placeholder="برای فیلتر کردن، تایپ کنید..."></div>' +
        '</div>' +
        '<div class="list-wrap" id="userViewList" style="margin-top:14px;"><div class="list-empty">در حال بارگذاری...</div></div>' +
      '</div>' +
      '<div class="panel">' +
        '<h3>ویرایش / غیرفعال‌سازی کاربران</h3>' +
        '<div class="list-wrap" id="userListWrap"><div class="list-empty" id="userListEmpty">در حال بارگذاری...</div></div>' +
      '</div>';

    document.getElementById('userAddForm').addEventListener('submit', function(e){
      e.preventDefault();
      var roleSelect = document.getElementById('uaRole');
      var branchInput = document.getElementById('uaBranch');
      var body = {
        username: document.getElementById('uaUsername').value.trim(),
        password: document.getElementById('uaPassword').value,
        // مدیر شعبه اجازه نداره نقش/شعبه انتخاب کنه؛ بک‌اند خودش اجباراً «خبرنگار» + شعبه‌ی خودش رو ست می‌کنه
        new_role: roleSelect ? roleSelect.value : 'reporter',
        new_branch: branchInput ? branchInput.value.trim() : ''
      };
      fetch(API_BASE + '/users/', { method: 'POST', headers: apiHeaders(true), body: JSON.stringify(body) })
        .then(function(res){ return res.json().then(function(d){ return { ok: res.ok, d: d }; }); })
        .then(function(r){
          if(!r.ok){
            toast((r.d && (r.d.username || r.d.password || r.d.detail)) || 'خطا در ساخت کاربر');
            return;
          }
          toast('کاربر ساخته شد.');
          document.getElementById('userAddForm').reset();
          loadUsers();
        })
        .catch(function(){ toast('ارتباط با سرور برقرار نشد.'); });
    });

    document.getElementById('uvSearch').addEventListener('input', function(){
      paintUserView(lastUsersList, this.value.trim());
    });

    loadUsers();
  }

  // فهرست کاربران رو تو پنل «نمایش کاربر» فقط برای دیدن (بدون دکمه ویرایش/غیرفعال‌سازی) رسم می‌کنه
  var lastUsersList = [];
  function paintUserView(list, filterText){
    var wrap = document.getElementById('userViewList');
    if(!wrap) return;
    var filtered = list;
    if(filterText){
      var q = filterText.toLowerCase();
      filtered = list.filter(function(u){ return (u.username || '').toLowerCase().indexOf(q) !== -1; });
    }
    if(!filtered.length){
      wrap.innerHTML = '<div class="list-empty">' + (list.length ? 'کاربری با این نام پیدا نشد.' : 'هنوز کاربری اضافه نشده.') + '</div>';
      return;
    }
    wrap.innerHTML = filtered.map(function(u){
      return (
        '<div class="list-row" style="' + (u.is_active ? '' : 'opacity:.55;') + '">' +
          '<span class="lr-badge">' + (ROLE_LABELS[u.role] || u.role) + (u.branch ? ' · ' + escapeHtml(u.branch) : '') + '</span>' +
          '<div class="lr-body"><h4>' + escapeHtml(u.username) + (u.is_active ? '' : ' (غیرفعال)') + '</h4>' +
            '<p>عضویت: ' + escapeHtml((u.date_joined || '').slice(0,10)) + '</p></div>' +
          '<span class="lr-meta">' + (u.is_active ? 'فعال' : 'غیرفعال') + '</span>' +
        '</div>'
      );
    }).join('');
  }

  function loadUsers(){
    var wrap = document.getElementById('userListWrap');
    fetch(API_BASE + '/users/', { headers: apiHeaders(false) })
      .then(function(res){
        if(!res.ok) throw new Error('fail');
        return res.json();
      })
      .then(function(data){
        var list = Array.isArray(data) ? data : (data.results || []);
        lastUsersList = list;
        var uvSearch = document.getElementById('uvSearch');
        paintUserView(list, uvSearch ? uvSearch.value.trim() : '');
        if(list.length === 0){
          wrap.innerHTML = '<div class="list-empty">هنوز کاربری ساخته نشده.</div>';
          return;
        }
        wrap.innerHTML = list.map(function(u){
          return (
            '<div class="list-row" data-id="' + u.id + '" style="' + (u.is_active ? '' : 'opacity:.55;') + '">' +
              '<span class="lr-badge">' + (ROLE_LABELS[u.role] || u.role) + (u.branch ? ' · ' + escapeHtml(u.branch) : '') + '</span>' +
              '<div class="lr-body"><h4>' + escapeHtml(u.username) + (u.is_active ? '' : ' (غیرفعال)') + '</h4>' +
                '<p>عضویت: ' + escapeHtml((u.date_joined || '').slice(0,10)) + '</p></div>' +
              '<div class="lr-actions">' +
                '<button class="icon-btn" data-edit="' + u.id + '" title="ویرایش">✎</button>' +
                '<button class="icon-btn danger" data-toggle="' + u.id + '" data-active="' + u.is_active + '" title="' + (u.is_active ? 'غیرفعال کردن' : 'فعال کردن') + '">' +
                  (u.is_active ? trashIcon() : '↺') +
                '</button>' +
              '</div>' +
            '</div>'
          );
        }).join('');

        wrap.querySelectorAll('[data-toggle]').forEach(function(btn){
          btn.addEventListener('click', function(){
            var id = btn.getAttribute('data-toggle');
            var isActive = btn.getAttribute('data-active') === 'true';
            if(isActive && !confirm('این کاربر غیرفعال بشه؟ دیگه نمی‌تونه وارد بشه.')) return;
            fetch(API_BASE + '/users/' + id + '/', {
              method: 'PATCH', headers: apiHeaders(true), body: JSON.stringify({ is_active: !isActive })
            })
              .then(function(res){ if(!res.ok) throw new Error('fail'); return res.json(); })
              .then(function(){ toast(!isActive ? 'کاربر فعال شد.' : 'کاربر غیرفعال شد.'); loadUsers(); })
              .catch(function(){ toast('خطا در بروزرسانی کاربر.'); });
          });
        });

        wrap.querySelectorAll('[data-edit]').forEach(function(btn){
          btn.addEventListener('click', function(){
            var id = btn.getAttribute('data-edit');
            var row = list.find(function(x){ return String(x.id) === String(id); });
            openEditUser(id, row);
          });
        });
      })
      .catch(function(){
        wrap.innerHTML = '<div class="list-empty">ارتباط با سرور برقرار نشد یا اجازه دسترسی نداری.</div>';
        var uvWrap = document.getElementById('userViewList');
        if(uvWrap) uvWrap.innerHTML = '<div class="list-empty">ارتباط با سرور برقرار نشد یا اجازه دسترسی نداری.</div>';
      });
  }

  function openEditUser(id, row){
    var body = {};

    if(IS_ADMIN){
      var newRole = prompt(
        'نقش جدید رو بنویس: admin (مدیرکل) / branch_manager (مدیر شعبه) / reporter (خبرنگار)\nبرای بی‌خیال شدن، خالی بذار.',
        row ? row.role : 'reporter'
      );
      if(newRole === null || newRole.trim() === '') return;
      newRole = newRole.trim();
      if(['admin','branch_manager','reporter'].indexOf(newRole) === -1){
        toast('مقدار نقش نامعتبره. فقط admin، branch_manager یا reporter مجاز است.');
        return;
      }
      var newBranch = prompt('شعبه (برای مدیر شعبه/خبرنگار) را بنویس، برای مدیرکل خالی بذار:', row ? (row.branch || '') : '');
      body.new_role = newRole;
      body.new_branch = (newBranch || '').trim();
    }
    // برای «مدیر شعبه»، نقش/شعبه‌ی خبرنگار همیشه ثابت می‌مونه (بک‌اند اجباراً reporter + شعبه‌ی خودش رو ست می‌کنه)

    var newPassword = prompt('اگه می‌خوای رمز عبور عوض بشه بنویس، وگرنه خالی بذار:', '');
    if(newPassword) body.password = newPassword;

    if(!IS_ADMIN && !newPassword){ return; }

    fetch(API_BASE + '/users/' + id + '/', { method: 'PATCH', headers: apiHeaders(true), body: JSON.stringify(body) })
      .then(function(res){ if(!res.ok) throw new Error('fail'); return res.json(); })
      .then(function(){ toast('کاربر ویرایش شد.'); loadUsers(); })
      .catch(function(){ toast('خطا در ویرایش کاربر.'); });
  }

  function trashIcon(){
    return '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">' +
      '<path d="M4.5 7h15M9.5 7V5.2a1.5 1.5 0 011.5-1.5h2a1.5 1.5 0 011.5 1.5V7M18 7l-.8 12.1a2 2 0 01-2 1.9H8.8a2 2 0 01-2-1.9L6 7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>' +
      '</svg>';
  }

  var renderers = {
    services: renderServices,
    mainSlider: renderMainSlider,
    latestNews: renderLatestNews,
    links: renderLinks,
    newsSlider: renderNewsSlider,
    publish: renderPublish,
    users: renderUsers
  };

  updateCounts();
})();
